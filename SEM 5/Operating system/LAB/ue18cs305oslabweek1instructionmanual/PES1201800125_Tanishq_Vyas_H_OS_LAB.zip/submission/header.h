#include <stdio.h>
#include <stdlib.h>

void printArray(int size, int arr[]);
void printReverseArray(int size, int arr[]);