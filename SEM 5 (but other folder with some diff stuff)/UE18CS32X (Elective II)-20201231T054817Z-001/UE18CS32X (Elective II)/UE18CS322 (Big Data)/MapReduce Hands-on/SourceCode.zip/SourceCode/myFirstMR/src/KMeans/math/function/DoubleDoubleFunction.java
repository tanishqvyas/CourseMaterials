package KMeans.math.function;

public interface DoubleDoubleFunction {

  public double apply(double left, double right);

}
