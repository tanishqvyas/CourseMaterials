package KMeans.distance;


import KMeans.math.DoubleVector;

public final class ZeroDistance implements DistanceMeasurer {

	@Override
	public double measureDistance(double[] set1, double[] set2) {
		return 0.0d;
	}

	@Override
	public double measureDistance(DoubleVector vec1, DoubleVector vec2) {
		return 0.0d;
	}

}
