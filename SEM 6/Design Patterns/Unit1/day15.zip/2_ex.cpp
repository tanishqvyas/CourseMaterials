// return mechanism
#include <iostream>
using namespace std;
int f1(int x)
{
	return x;
}
// return by reference:
//	reference should refer to something which has life in the calling environment
//  reference :
//		use as l-value : return reference to a variable
//		efficiency
//		do not use as l-value :  return reference to a const
int& f2(int& x)
{
	return x;
}
const int& f5(int& x)
{
	return x;
}
// b = f5(a); // ok
// f5(a) = 20; // not compile

int f3(int& x)
{
	return x;
}

// returning a reference to a local variable
// dangling reference
int& f4(int x) // NEVER USE
{
	return x;
}


int main()
{
	{
		int a(10); int b;
		b = f1(a);
	}
	{
		int a(10); int b;
		b = f2(a);
	
	}
	{
		int a(10); int b;
		f2(a) = 20;
	
	}
	{
		int a(10); int b;
		b = f3(a);
		// f3(a) = 20; // compile time error
	}
	{
		int a(10); int b;
		b = f4(a);
	}
	
	
}
