#include <stdio.h>
#include "2_server.h"
#include "2_server.h"



int main()
{
	rect_t r1; // struct variable definition
}
