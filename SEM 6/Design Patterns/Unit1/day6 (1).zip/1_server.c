#include <stdio.h>
#include "1_server.h"
int a = 10; // definition; also initialized
//extern static int b;
void foo()
{
	//printf("foo : b : %d\n", b);
}
