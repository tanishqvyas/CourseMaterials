// use pre-processor to include a file only once
// canonical way of writing header files
// 2. #pragma once
#ifndef SERVER_H
#define SERVER_H
// struct type definition:
//		binary layout of structure
//		relative position of fields
//		only for the compiler 
struct Rect
{
	int length;
	int breadth;
};
typedef struct Rect rect_t; // make an interface
// rect_t r; // should not be allowed; goes to the linker
#endif

