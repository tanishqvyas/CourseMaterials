// int a = 10; // causes multiple definition; by linker

extern int a; // declaration

