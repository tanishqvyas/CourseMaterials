#include <stdio.h>
#include "3_rect.h"
