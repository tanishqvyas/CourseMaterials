#include <stdio.h>
#include "3_rect.h"

int main()
{
	rect_t r;
	init(&r, 20, 10);
	printf("area : %d\n", area(&r));
	printf("peri : %d\n", peri(&r));
	disp(&r);
	
}
