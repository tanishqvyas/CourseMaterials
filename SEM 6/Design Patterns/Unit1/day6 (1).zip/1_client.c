#include <stdio.h>
#include "1_server.h"

static int b = 20; // external static

int main()
{
	printf("a : %d\n", a);
	printf("b : %d\n", b);
}

