#include <stdio.h>

int main()
{
	printf("one\n");
	printf("cube : %d\n", cube(5));
	printf("cube : %d\n", cube(10, 20));
	printf("two\n");
}
// activation record or stack frame
// filled by the caller
// 1. return address
// 2. parameters
// filled by the callee
// 3. local variables
// 4. temporary variables

// return is always thro a temporary - accessible
//	to both the caller and the callee


// what happens?
// - fn  name - is this changed by the compiler?
// - when are the arguments evaluated ?
//		before the call or during the execution of
//		the function?
//	- what is the order of evaluation of arguments?
//  - what is the order of stacking?
//  - who cleans the stack?

