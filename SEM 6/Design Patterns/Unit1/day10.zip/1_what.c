#include <stdio.h>

struct A
{
	int x;
	int y;
	int z;
};
struct B
{
	int x;
	int y;
	int *z;
};
struct C
{
	int x;
	int y;
	int z[1];
};
// diff : pointer and array of 1 element
int main()
{
	struct B b;
	b.x = 5;
	b.z = (int*)malloc(sizeof(int) * b.x);
	
	struct B *pb; 
	pb = (struct B*)malloc(sizeof(struct B));
	pb->x = 5;
	pb->z = (int*)malloc(sizeof(int) * b->x);
	
	// struct hacking
	// keep the memory contiguous
	// cache friendly
	struct C *pc; int size = 5;
	pc = (struct C*)malloc(sizeof(struct C) + sizeof(int) * (size - 1));
	pc->x = 5;
}
// function calls are considered costly :
//	may result in cache invalidation on call 
//		as well as return	
//	locality of reference (temporal and spatial)

// watch:
//	why we should not use linked list :
//		Bjarne Stroustrup

