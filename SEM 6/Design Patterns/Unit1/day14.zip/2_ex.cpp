#include <iostream>
using namespace std;
#include <cstring>

#if 0
class MyStr
{
	private:
	char *p_;
	public:
	MyStr(char *p);
	void disp();
};

MyStr::MyStr(char *p)
: p_(p)
{
}

void MyStr::disp()
{
	cout << p_ << "\n";
}
int main()
{
	char name[] = "pesu";
	MyStr s1(name);
	s1.disp();
	name[0] = ' ';
	s1.disp();
}
#endif
class MyStr
{
	private:
	char *p_;
	public:
	MyStr(char *p);
	~MyStr();
	void disp();
};

// 1. alloc memory
// 2. copy str
MyStr::MyStr(char *p)
: p_(new char[strlen(p) + 1])
{
	strcpy(p_, p);
}

MyStr::~MyStr()
{
	delete [] p_;
}

void MyStr::disp()
{
	cout << p_ << "\n";
}
int main()
{
	char name[] = "pesu";
	{
	MyStr s1(name);
	s1.disp();
	name[0] = ' ';
	s1.disp();
	}
	
	{
		char name2[] = "abcd";
		char name3[] = "pqrstuvw";
		MyStr s2(name2);
		MyStr s3(name3);
		s2 = s3; // assignment
		s2.disp();
		s3.disp(); 
	}
	
}
// valgrind : memory leak check
