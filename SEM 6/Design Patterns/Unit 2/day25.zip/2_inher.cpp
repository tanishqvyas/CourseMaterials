#include <iostream>
using namespace std;

class A
{
	public:
	void foo() const {  cout << "foo A\n"; }
	virtual void bar() const { cout << "bar A\n"; }
};

class B : public A
{
	public:
	void foo() const {  cout << "foo B\n"; }
	virtual void bar() const { cout << "bar B\n"; }
};
int main()
{
	A *p;
	A x;
	B y;
	// call with a pointer to base class; non virtual fn => always call the fn 
	//	of the base class
	// call with a pointer to base class; virtual fn => call the fn based on
	//	the type of object to which the pointer points to 
	p = &x; p->foo(); p->bar();
	p = &y; p->foo(); p->bar();
  
}

// overriding : modify the behaviour of the base class
// - virtual fns
// - fns in diff scope
// - should have relation of inheritance
// - dispatch is dynamic
// - three overheads
//		table per class, pointer per object, extra dereferencing at runtime

