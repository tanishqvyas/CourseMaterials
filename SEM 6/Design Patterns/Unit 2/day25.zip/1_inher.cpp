#include <iostream>
using namespace std;

class A
{
	private:
	int a_;
	public:
	A(int a) : a_(a) { cout << "ctor A\n"; }
	~A() { cout << "dtor A\n"; } 
};
// member initialization list:
//	2. call to base class ctor
//	3. initialize members of the same class
class B : public A
{
	private:
	int b_;
	public:
	B(int a, int b) : A(a), b_(b) { cout << "ctor B\n"; }
	~B() { cout << "dtor B\n"; } 
};
// derived class object has an unnamed object of the base class
int main()
{
	B y(11, 22);
}
