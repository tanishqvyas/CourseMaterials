a = [10, 20]
b = a
print(id(a))
print(id(b))

"""
c = [30, 40]
b = c
# will a change?
print(a)
"""

b.append(30)
# will a change?
print(a)

import sys
print(sys.getrefcount(a))

