#ifndef SHAPE_H
#define SHAPE_H
#include "rect.h"
#include "circle.h"
union ShapeUnion
{
	Rect r_;
	Circle c_;
};
class Shape
{
	private:
	ShapeUnion su_;
	char st_; // shape type : r : rect; c : circle
	public:
	void read();
	void disp() const;
	double area() const;
	double peri() const;
};
#endif
