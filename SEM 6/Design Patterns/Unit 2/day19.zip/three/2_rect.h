#ifndef RECT_H
#define RECT_H

#if 1
// a mutable member of a class can be changed even in a const function

// from client's point of view : rect has length and breadth
// for out reasons, we have added a couple of implementation fields
//  outside the client's abstraction
// modifying these implementation fields outside the client's abstraction
//		in a const function does not affect the client's abstraction

class Rect
{
	private:
	int length_;
	int breadth_;
	mutable int area_; // implementation field
	mutable bool is_changed_;
	public:
	Rect(int length, int breadth);
	// 
	int find_area() const;
	void change_length(int length);
	void change_breadth(int breadth);
};
#endif

#endif

