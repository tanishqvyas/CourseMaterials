#ifndef MYSTR_H
#define MYSTR_H
// Ref counting class
//	- RC class is associated with MyStr - not for the client
//	- hide a class : make all ctors private
//	
//	- we want MyStr class to create objects of RC and play with them
//	  concept : friend class :
//		used to hide a class
//		implementation class

class RC
{
	private:
	char *s_;
	int count_;
	// public:
	RC(const char* s);
	~RC();
	void disp() const;
	friend class MyStr;
};

class MyStr
{
	private:
	RC *ptr_rc_;
	public:
	MyStr(const char* s);
	MyStr(const MyStr&);
	~MyStr();
	void disp() const;
};
#endif

