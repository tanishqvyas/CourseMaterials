r = range(5)
print(r)
m = map(lambda x : x, range(5)) 
# 2 argument : callable, iterable; # of arguments for callable : 1
print(m)

for e in r :
	print(e, end = " ")
print()

for e in m :
	print(e, end = " ")
print()

for e in r :
	print(e, end = " ")
print()
print("-----")
for e in m :
	print(e, end = " ")
print()
print("-----")



