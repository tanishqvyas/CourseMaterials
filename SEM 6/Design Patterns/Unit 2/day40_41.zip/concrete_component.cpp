#include <iostream>
using namespace std;
#include "concrete_component.h"

void Concrete_Component::operation()
{
	cout << "concrete component : operation\n";
	
}
