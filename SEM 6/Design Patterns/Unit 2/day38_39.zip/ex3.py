"""
# version 1
def foo() :
	print("hello world")
foo()
"""

"""
# version 2
def foo() :
	def what() :
		print("hello world")
	what()
foo()
"""
"""
# version 3
def foo() :
	def what() :
		print("hello world")
	return what
foo()()
"""
"""
# version 4
def foo() :
	def what() :
		print("hello world")
	return what
p = foo()
p()
"""

"""
# version 5
def foo(test) :
	def what() :
		test()
	what()
	
def myfn() :
	print("hello world")
foo(myfn)
"""
"""
# version 6
def foo(test) :
	def what() :
		test()
	return what
	
def myfn() :
	print("hello world")
	
bar = foo(myfn)
bar()
"""
"""
# version 7
def foo(test) :
	def what() :
		print("before")
		test()
	return what
	
def myfn() :
	print("hello world")
	
bar = foo(myfn)
bar()
"""
# engineered decorator
# version 8
def foo(test) :
	def what() :
		print("before")
		test()
	return what
	
def myfn() :
	print("hello world")


#myfn()
 	
myfn = foo(myfn)
myfn()







