#include <iostream>
using namespace std;
/*
	make the dtor of the base class virtual whenever the derived class
		ctor is non-trivial
	rule of C++:
	not every class is meant for inheritance
	if a class has no virtual fns, class is not object oriented class
		such a class is object based
		should not have a virtual dtor
	if a class has virtual fns, class is for inheritance - 
		such a class is object oriented
		should have a virtual dtor
	As a derived class developer, I should not inherit from a base class
		with no virtual dtor for polymorphic usage
			
*/
class A
{
	public:
	A() { cout << "ctor A\n"; }
	virtual ~A() { cout << "dtor A\n"; }
	class X { };
	class Y { };
	typedef mytype Y;
};

class B : public A
{
	private:
	int* p_;
	public:
	B() : p_(new int[5]) { cout << "ctor B\n"; }
	virtual ~B() { delete [] p_; cout << "dtor B\n"; }
	class Y { };
	typedef mytype Y;	
};

A::mytype a;
B::mytype b;

int main()
{
	{
	//	A x; // ctor A dtor A
	}
	{
	//	B y; // ctor A ctor B
	} // dtor B dtor A
	{
		A *p = new B;
		delete p;
	}
	
	// inheritance for reuse
	A::X x1; // A::X
	B::X x2; // A::X
	
	A::Y y1; // A::Y
	B::Y y2; // B::Y
	

}
