#include "visitor.h"

Visitor::~Visitor()
{
}
