#include "body.h"

Body::~Body()
{
}
