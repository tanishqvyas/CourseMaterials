#include "lid.h"

Lid::~Lid()
{
}

