#ifndef LID_H
#define LID_H
class Lid
{
	public:
	virtual ~Lid() = 0;
};
#endif
