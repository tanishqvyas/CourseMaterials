#ifndef BODY_H
#define BODY_H
class Body
{
	public:
	virtual ~Body() = 0;
};
#endif

