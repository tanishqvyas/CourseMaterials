#ifndef PRESTIGE_BODY
#define PRESTIGE_BODY
#include "body.h"
class Prestige_Body : public Body
{
	
};
#endif

