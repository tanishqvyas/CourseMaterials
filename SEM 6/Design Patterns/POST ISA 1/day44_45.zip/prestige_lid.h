#ifndef PRESTIGE_LID_H
#define PRESTIGE_LID_H
#include "lid.h"
class Prestige_Lid : public Lid
{
};
#endif

