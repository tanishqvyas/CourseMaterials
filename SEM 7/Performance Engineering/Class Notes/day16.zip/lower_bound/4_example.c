/*
array sorted in non decreasing order
elements repeat
 0  1  2  3  4  5  6  7  8  9 10 11 12
10 10 10 20 20 20 20 20 30 40 40 40 50

lb(10) = 0
lb(20) = 3
lb(30) = 8
lb(40) = 9
lb(50) = 12

*/
#include <stdio.h>
#include <stdlib.h>

// repeat numbers : 0 1 2 3 ...
// each # at most occurs n / 10 times
int init(int a[], int n)
{
	int i = 0; // key
	int j = 0; // index
	int max_step = n / 10;
	while(1)
	{
		int size = rand() % max_step;
		while(j < n && size--)
		{
			a[j] = i;
			++j;
		}
		if(j == n)
			break;
		++i;
	}
	return i;
}



int lower_bound(int a[], int n, int e)
{
	// hard coded for n = 1000
	int l = -1; int i = 512; // biggest exact power of 2 less than 1000
	if(a[511] < e) l = 1000 - 512;
	if(a[l + 256] < e) l += 256;
	if(a[l + 128] < e) l += 128;
	if(a[l + 64] < e) l += 64;
	if(a[l + 32] < e) l += 32;
	if(a[l + 16] < e) l += 16;
	if(a[l + 8] < e) l += 8;
	if(a[l + 4] < e) l += 4;
	if(a[l + 2] < e) l += 2;
	if(a[l + 1] < e) l += 1;
	int r = l + 1;
	return (a[r] == e) ? r : -1;
	
}
void test(int a[], int n, int e)
{
	int lb = lower_bound(a, n, e);
	if(lb == -1)
	{
		printf("%d not found\n", e);
	}
	else
	{
		printf("e : %d lb :  %d\n", e, lb);
	}
}
int main()
{
	int n = 1000;
	int a[n];
	int max = init(a, n);
	for(int i = 0; i <= max; ++i)
	{
		test(a, n, i);
	}
}

