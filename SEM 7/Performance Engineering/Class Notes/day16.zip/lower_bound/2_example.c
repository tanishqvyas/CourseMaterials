/*
array sorted in non decreasing order
elements repeat
 0  1  2  3  4  5  6  7  8  9 10 11 12
10 10 10 20 20 20 20 20 30 40 40 40 50

lb(10) = 0
lb(20) = 3
lb(30) = 8
lb(40) = 9
lb(50) = 12

*/
#include <stdio.h>
#include <stdlib.h>

// repeat numbers : 0 1 2 3 ...
// each # at most occurs n / 10 times
int init(int a[], int n)
{
	int i = 0; // key
	int j = 0; // index
	int max_step = n / 10;
	while(1)
	{
		int size = rand() % max_step;
		while(j < n && size--)
		{
			a[j] = i;
			++j;
		}
		if(j == n)
			break;
		++i;
	}
	return i;
}



int lower_bound(int a[], int n, int e)
{
	int l = -1; int r = n; int m = -1;
	while(l + 1 != r) // l and r are adjacent indices
	{
		m = (l + r) / 2;
		if(a[m] < e)
		{
			l = m;
		}
		else
		{
			r = m;
		}
	}
	return (a[r] == e) ? r : -1;
}
void test(int a[], int n, int e)
{
	int lb = lower_bound(a, n, e);
	if(lb == -1)
	{
		printf("%d not found\n", e);
	}
	else
	{
		printf("e : %d lb :  %d\n", e, lb);
	}
}
int main()
{
	int n = 1000;
	int a[n];
	int max = init(a, n);
	for(int i = 0; i <= max; ++i)
	{
		test(a, n, i);
	}
}

