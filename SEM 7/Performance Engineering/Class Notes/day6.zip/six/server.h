#ifndef SERVER_H
#define SERVER_H
#define MAX 1024
extern int c;
// # of comparisons while sorting an array of n elements by quicksort

void count(int n); 
#endif

