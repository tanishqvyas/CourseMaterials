#include <stdio.h>
#include "server.h"

int main()
{
	int n = MAX;
	count(n);
	printf("# of comparisons : %d\n", c);
}
