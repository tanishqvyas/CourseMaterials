#include <stdio.h>
#include <stdlib.h>
#include "server.h"

int c = 0;

void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = rand() % 10000;
	}
}

void disp(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}

void myswap(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

#if 0
// Lomuto's partition
int partition(int a[], int l, int r)
{
	int n = (r - l) + 1;
	int m = l;
	myswap(&a[l], &a[rand() % n + l]);
	for(int i = l + 1; i <= r; ++i)
	{
		++c;
		if(a[i] < a[l])
		{
			myswap(&a[i], &a[++m]);
		}
	}
	myswap(&a[l], &a[m]);
	return m;
}
// l = 0; r = 7
//  i 1 2 3 4 5 6 7
//  m 0 1 2 3 4
//  0  1  2 3   4  5  6 7
// 30 20 15 60 40 35 10 5
// 30 20 15 60 40 35 
// 30 20 15 10 40 35 60
// 30 20 15 10 5  35 60 40

// 5 20 15 10 30 35 60 40
//   
#endif

// make counting faster
int partition(int a[], int l, int r)
{
	int n = (r - l) + 1;
	int m = l;
	myswap(&a[l], &a[rand() % n + l]);
	
	//c += r - (l + 1) + 1
	c += r - l;
	
	for(int i = l + 1; i <= r; ++i)
	{
	//	++c;
		if(a[i] < a[l])
		{
			myswap(&a[i], &a[++m]);
		}
	}
	myswap(&a[l], &a[m]);
	return m;
}


void mysort(int a[], int l, int r)
{
	if(l < r)
	{
		int m = partition(a, l, r);
		mysort(a, l, m - 1);
		mysort(a, m + 1, r);
	}	
}

// not decreasing order
int is_sorted(int a[], int n)
{
	for(int i = 0; i < n - 1; ++i)
	{
		if(a[i + 1] < a[i])
			return 0;
	}
	return 1;
}




