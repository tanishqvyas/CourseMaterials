#include <stdio.h>
#include <stdlib.h>
#include "server.h"

int c = 0;

void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = rand() % 10000;
	}
}

void disp(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}

void myswap(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}


#if 0
// replace qsort by count
// no more global variable
// pass a single arg to partition
int partition(int n)
{
	int m = rand() % n;
	c += n - 1;
	return m;
}


void count(int n)
{
	if(n > 1)
	{
		int m = partition(n);
		count(m - 1);
		count(n - m);
	}	
}
#endif

int count(int n)
{
	if(n <= 1) return 0;
	int m = rand() % n;
	return (n - 1) + count(m - 1) + count(n - m);
		
}


// not decreasing order
int is_sorted(int a[], int n)
{
	for(int i = 0; i < n - 1; ++i)
	{
		if(a[i + 1] < a[i])
			return 0;
	}
	return 1;
}




