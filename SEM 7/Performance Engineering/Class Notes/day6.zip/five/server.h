#ifndef SERVER_H
#define SERVER_H
#define MAX 1024
extern int c;
void mysort(int l, int r);
#endif

