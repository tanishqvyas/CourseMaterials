#include <stdio.h>
#include <stdlib.h>
#include "server.h"

void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = rand() % 10000;
	}
}

void disp(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}

void myswap(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}
// Hoare's partition
int partition(int a[], int l, int r)
{
	int n = (r - l) + 1;
	myswap(&a[l], &a[rand() % n + l] );
	int i = l;
	int j = r + 1;
	int p = a[l];
	do
	{
		do
		{
			++i;
		}
		while(i <= r && a[i] < p);
		
		do
		{ 
			--j;
		}
		while(j >= l && a[j] > p);
		myswap(&a[i], &a[j]);
	}
	while(i < j);
	myswap(&a[i], &a[j]);
	myswap(&a[j], &a[l]);
	printf("j : %d ", j);
	disp(a, n);
	return j;
}

void mysort(int a[], int l, int r)
{
	if(l < r)
	{
		int m = partition(a, l, r);
		mysort(a, l, m - 1);
		mysort(a, m + 1, r);
	}	
}

// not decreasing order
int is_sorted(int a[], int n)
{
	for(int i = 0; i < n - 1; ++i)
	{
		if(a[i + 1] < a[i])
			return 0;
	}
	return 1;
}




