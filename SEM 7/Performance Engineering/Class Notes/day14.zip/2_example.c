#include <stdio.h>
#include <stdlib.h>
#include <time.h>
// find min and max

struct min_max
{
	int min_;
	int max_;
};
typedef struct min_max min_max_t;

void fill(int a[], int n)
{
	srand(time(0));
	for(int i = 0; i < n; ++i)
	{
		a[i] = rand() % 100000;
	}
	
}
#if 0
// 2n - 2 comparisons
min_max_t find_min_max(int a[], int n)
{
	int min = a[0]; int max = a[0];
	for(int i = 1; i < n; ++i)
	{
		if(a[i] < min)
			min = a[i];
		if(a[i] > max)
			max = a[i];
	}
	min_max_t res = { min, max };
	return res;
	
}
#endif
// ~3n/2
min_max_t find_min_max(int a[], int n)
{
	int i;
	int min; int max;
	if(n % 2)
	{
		min = max = a[0];
		i = 1;
	}
	else
	{
		min = a[0]; max = a[1];
		if(min > max)
		{
			int temp = min; min = max; max = temp;
		}
		i = 2;

	}
	while(i < n)
	{
		if(a[i] > a[i + 1])
		{
			if(a[i] > max)
				max = a[i];
			if(a[i+1] < min)
				min = a[i+1];
		}
		else
		{
			if(a[i + 1] > max)
				max = a[i + 1];
			if(a[i] < min)
				min = a[i];
		}
		
		i += 2;
	}
	min_max_t res = { min, max };
	return res;
	
}

int main()
{
	int n = 10000;
	int a[n];
	fill(a, n);
	min_max_t res;
	res = find_min_max(a, n);
	printf("min : %d max : %d\n", res.min_, res.max_);		
}
