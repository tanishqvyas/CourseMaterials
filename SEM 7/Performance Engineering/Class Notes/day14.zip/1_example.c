// count the number of bits which are 1 in a given number

#include <stdio.h>

#if 0
// version 1
int bit_count(unsigned int n)
{
	int c = 0;
	while(n)
	{
		c += n & 1;
		n >>= 1;
	}
	return c;
}
#endif
#if 0
// version 2
int bit_count(unsigned int n)
{
	int c = n & 1;
	while(n >>= 1)
	{
		c += n & 1;
	}
	return c;
}
#endif
// n &(n-1) == 0 # exact power of two 
// exact power of 2 :
//	00000001000000000
//  00000000111111111

//  00001000100000000
//  00001000011111111

#if 0
// version 3
int bit_count(unsigned int n)
{
	int c = 0;
	while(n)
	{
		n = n & (n-1);
		++c;
	}
	return c;
}
#endif

#if 1
//version 4
int bit_count_(unsigned int n)
{
	int c = 0;
	while(n)
	{
		c += n & 1;
		n >>= 1;
	}
	return c;
}
void make_table(int t[])
{
	for(unsigned int i = 0; i < 256; ++i)
	{
		t[i] = bit_count_(i);
	}
}
int bit_count(unsigned int n)
{
	static int t[256];
	static int first = 1;
	if(first)
	{
		make_table(t);
		first = 0;
	}
	int c = 0;
	while(n)
	{
		c += t[n & 0xff];
		n >>= 8;
	}
	return c;
}
#endif

int main()
{
	unsigned int n = 1000;
	unsigned int m = 10000;
	int s = 1000;
	for(int i = n;  i <= m; i += s)
	{
		printf("%u : %d\n", i, bit_count(i)); 
	}
} 

