#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}

int fill(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = rand() % 10000;
	}
}
// indices 1 .. n
int check_sorted(int a[], int n)
{
	for(int i = 1; i < n; ++i)
	{
		if(a[i + 1] < a[i])
			return 0;
	}
	return 1;
}
void myswap(int *p, int *q)
{
	int temp = *p;
	*p = *q;
	*q = temp;
}
// int x[10000] = {0}; // bad for embedded

// version 3
// - inline the code for swap
void insert_sort(int a[], int n)
{
	// a[i] is the element to  be insertedd
	// i - 1 : section of the array sorted so far
	for(int i = 2; i <= n; ++i)
	{
		int j = i;
		while(j > 1 && a[j-1] > a[j])
		{
			// myswap(&a[j], &a[j-1]);
			int temp = a[j]; a[j] = a[j-1]; a[j-1] = temp;
			--j;
		}
	} 
}
void disp(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}
int main()
{
	int n = 10000;
	int a[n+1]; // indices : 1 .. 10000
	fill(a, n);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	

	insert_sort(a, n);

	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
			   
	printf("sorted : %d\n", check_sorted(a, n));
	//disp(a, n);
}

/*
version 2
./a.out
time 0.477671 
sorted : 1
$ ./a.out
time 0.457649 
sorted : 1
$ ./a.out
time 0.583761 
sorted : 1
$ ./a.out
time 0.469330 
sorted : 1

*/
/*
// version 3
./a.out
time 0.207177 
sorted : 1
$ ./a.out
time 0.214040 
sorted : 1
$ ./a.out
time 0.209729 
sorted : 1
$ ./a.out
time 0.211564 
sorted : 1

*/
