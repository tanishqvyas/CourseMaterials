#include <stdio.h>
#include <stdlib.h>
int fill(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = rand() % 10000;
	}
}
// indices 1 .. n
int check_sorted(int a[], int n)
{
	for(int i = 1; i < n; ++i)
	{
		if(a[i + 1] < a[i])
			return 0;
	}
	return 1;
}
void myswap(int *p, int *q)
{
	int temp = *p;
	*p = *q;
	*q = temp;
}
// 10 5
// version 1
// indices : 1 .. n
void insert_sort(int a[], int n)
{
	// a[i] is the element to  be insertedd
	// i - 1 : section of the array sorted so far
	for(int i = 2; i <= n; ++i)
	{
		int j = i;
		while(j > 1 && a[j-1] > a[j])
		{
			myswap(&a[j], &a[j-1]);
			--j;
		}
	} 
}
void disp(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
}
int main()
{
	int n = 10;
	int a[n+1]; // indices : 1 .. 10 
	fill(a, n);
	insert_sort(a, n);
	printf("sorted : %d\n", check_sorted(a, n));
	disp(a, n);
}
