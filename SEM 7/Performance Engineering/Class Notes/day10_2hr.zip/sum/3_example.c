#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
void fill(int a[], int n)
{
	// filled # from 1 to n
	for(int i = 0; i < n; ++i)
	{
		a[i] = i + 1;
	}
}

// assumption that n is a multiple of 4 :relax this assumption
// loop unrolling
int sum(int a[], int n)
{
	int s = 0; int i = 0;
	switch(n%4)
	{
		case 3: s += a[i]; ++i;
		case 2: s += a[i]; ++i;
		case 1: s += a[i]; ++i;
	}
	for(; i < n; i += 4)
	{
		s += a[i] + a[i+1] + a[i+2] + a[i+3];
	}
	return s;
}
int main()
{
	int n = 25;
	int a[n];
	fill(a, n);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	int s = sum(a, n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
			   
	printf("sum : %d\n", s);
	printf("correct : %d\n", s == n*(n+1)/2);
	
}

/*
$ ./a.out
time 0.000275 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000275 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000337 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000275 
sum : 1250025000
correct : 1

*/
/*
./a.out
time 0.000073 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000081 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000073 
sum : 1250025000
correct : 1
$ ./a.out
time 0.000090 
sum : 1250025000
correct : 1

*/
