// sum of elements in an array is below a threshold
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void fill(int a[], int n)
{
	srand(time(0));
	for(int i = 0; i < n; ++i)
	{
		a[i] = rand() % 100;
	}
	
}
#if 0
// version 1
int exceeds_limit(int a[], int n, int limit)
{
	int s = 0;
	for(int i = 0; i < n; ++i)
	{
		s += a[i];
	}
	printf("sum : %d limit : %d\n", s , limit);
	return s > limit;
}
#endif
// version 2
int exceeds_limit(int a[], int n, int limit)
{
	int s = 0;
	for(int i = 0; i < n && s <= limit; ++i)
	{
		s += a[i];
	}
	printf("sum : %d limit : %d\n", s , limit);
	return s > limit;
}
int main()
{
	int n = 1000;
	int a[n];
	fill(a, n);
	printf("exceeded the limit : %d\n", exceeds_limit(a, n, 49500));
}
