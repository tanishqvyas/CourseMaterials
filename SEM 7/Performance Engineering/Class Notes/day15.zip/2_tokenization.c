// space => 1  letter => 2 digit => 3 additive op => 4 mul op => 5 others => 6
#include <stdio.h>
#if 0
// version 1:
// naive
int classify(char ch)
{
	if(ch == '*' || ch == '/' || ch == '%')
		return 5;
	else if(ch == '+' || ch == '-')
		return 4;
	else if(ch >= '0' && ch <= '9')
		return 3;
	else if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
		return 2;
	else if(ch == ' ')
		return 1;
	else
		return 6;
}
#endif
#if 0
// version 2:
// most frequent character be classified in the earlier clauses
// arrange clauses based on decreasing order of frequency

// most common ordering : space digit letter operator
int classify(char ch)
{
	if(ch == ' ')
		return 1;
	else if(ch >= '0' && ch <= '9')
		return 3;
	else if((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
		return 2;
	else if(ch == '*' || ch == '/' || ch == '%')
		return 5;
	else if(ch == '+' || ch == '-')
		return 4;
	else
		return 6;
}
#endif

// version 3:
// time space tradeoff
// more space to gain in time
// table driven technique
int classify(char ch)
{

	static int t[256];
	static int first = 1;
	if(first)
	{
		for(int i = 0; i < 256; ++i)
		{
			t[i] = 6;
		}
	
		t[' '] = 1;
		for(int i = '0'; i <= '9'; ++i)
		{
			t[i] = 3;
		}
		for(int i = 0; i < 26; ++i)
		{
			t['A' + i] = t['a' + i] = 2;
		}
		t['*'] = t['/'] = t['%'] = 5;
		t['+'] = t['-'] = 4;
		first = 0;
	}
	return t[ch];
}

// infix to postfix :
//	a op1 b op2 c
//	left association
//  a - b - c
//	a b - c -

// right associative
//	a = b = c
//	a b c = = 

// op1 and op2 have the same precedence


int main()
{
	char ch;
	while((ch = getchar()) != EOF)
	{
		printf("%c => %d\n", ch, classify(ch));
	}
}
