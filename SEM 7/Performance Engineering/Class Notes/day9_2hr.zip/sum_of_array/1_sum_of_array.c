#include <stdio.h>
void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = i + 1;
	}
}
#if 0
// version 1
int sum(int a[], int n)
{
	int s = 0;
	for(int i = 0; i < n; ++i)
	{
		s += a[i];
	}
	return s;
}
#endif

#if 0
// n is divisible by 4
// version 2
int sum(int a[], int n)
{
	int s = 0;
	for(int i = 0; i < n; i += 4)
	{
		s += a[i] + a[i+1] + a[i+2] + a[i+3];
	}
	return s;
}
#endif

// n is not divisible by 4?
// version 3
int sum(int a[], int n)
{
	int s = 0;
	int i = 0;
	switch(n % 4)
	{
		case 3: s += a[2]; ++i;
		case 2: s += a[1]; ++i;
		case 1: s += a[0]; ++i;
	}
	for(; i < n; i += 4)
	{
		s += a[i] + a[i+1] + a[i+2] + a[i+3];
	}
	return s;
}


int main()
{
	int n = 102;
	int a[n];
	fill(a, n);
	printf("sum : %d\n", sum(a, n));
	
}
