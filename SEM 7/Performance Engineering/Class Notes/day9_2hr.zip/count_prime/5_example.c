#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}

	

#if 0
// version 3
// move the code out of the loop
int is_prime(int n)
{
	double sqrt_n = sqrt(n);
	for(int i = 2; i <= sqrt_n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif

// version 4
//  i <= sqrt(n)
//	i * i <= n
int is_prime(int n)
{
	for(int i = 2; i * i <= n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
int count_primes(int n)
{
	int c = 0;
	for(int i = 2; i <= n; ++i)
	{
		if(is_prime(i))
		{
			++c;
		}
	}
	return c;
}

int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	
	clock_gettime(CLOCK_REALTIME, &start);	
	int c = count_primes(n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
			   
	printf("# of primes : %d\n", c);
}



/*
version 3
time 0.046620 
# of primes : 9592
$ ./a.out
time 0.063141 
# of primes : 9592
$ ./a.out
time 0.046709 
# of primes : 9592
$ ./a.out
time 0.052922 
# of primes : 9592

*/
/*
$ ./a.out
time 0.051842 
# of primes : 9592
$ ./a.out
time 0.041520 
# of primes : 9592
$ ./a.out
time 0.041208 
# of primes : 9592
$ ./a.out
time 0.045699 
# of primes : 9592

*/
