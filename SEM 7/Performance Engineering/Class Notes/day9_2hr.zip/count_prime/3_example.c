#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
// version 1
int is_prime(int n)
{
	for(int i = 2; i < n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif
// factors occur in pairs
// 24
// 1 2 3 4 6 8 12 24
// 3)24(8
//   24
//	----
//	

// version 2
int is_prime(int n)
{
	for(int i = 2; i <= sqrt(n); ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}


int count_primes(int n)
{
	int c = 0;
	for(int i = 2; i <= n; ++i)
	{
		if(is_prime(i))
		{
			++c;
		}
	}
	return c;
}

int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	
	clock_gettime(CLOCK_REALTIME, &start);	
	int c = count_primes(n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
			   
	printf("# of primes : %d\n", c);
}

/*
// version 1
$ ./a.out
time 5.663352 
# of primes : 9592
$ ./a.out
time 5.498468 
# of primes : 9592
$ ./a.out
time 11.150239 
# of primes : 9592
$ ./a.out
time 5.933521 
# of primes : 9592

*/

/*
// version 2
$ ./a.out
time 0.111607 
# of primes : 9592
$ ./a.out
time 0.122786 
# of primes : 9592
$ ./a.out
time 0.114628 
# of primes : 9592
$ ./a.out
time 0.117911 
# of primes : 9592
*/
