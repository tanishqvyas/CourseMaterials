#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}


#if 0
// version 8
int is_prime(int n, int primes[], int size)
{
	for(int i = 0; i < size; ++i)
	{
		int factor = primes[i];
		if(factor * factor > n)
			return 1;
		if(n % factor == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif

#if 0
// version 9
int is_prime(int n, int primes[])
{
	for(int i = 0; primes[i]; ++i)
	{
		int factor = primes[i];
		if(factor * factor > n)
			return 1;
		if(n % factor == 0)
		{
			return 0;
		}
	}
	return 1;
}


int count_primes(int n)
{
	int primes[n/4 + 1]; // first 100 numbers have 25 primes
	primes[0] = 0;
	int size = 0;
	// do we have to store 2? NO
	
	int c = 1; // count 2 as prime
	for(int i = 3; i <= n; i += 2)
	{
		if(is_prime(i, primes))
		{
			++c;
			primes[size++] = i;
			primes[size] = 0;
		}
	}
	//printf("size : %d\n", size);
	return c;
}
#endif
// version 9

int is_prime(int n, int primes[])
{
	int factor;
	for(int i = 0; ; ++i)
	{
		factor = primes[i];
		if(n % factor == 0)
		{
			break;
		}
		if(factor * factor > n)
			return 1;

	}
	return n == factor;
}


int count_primes(int n)
{
	int primes[n/4 + 1]; // first 100 numbers have 25 primes
	primes[0] = 0;
	int size = 0;
	// do we have to store 2? NO
	
	int c = 1; // count 2 as prime
	for(int i = 3; i <= n; i += 2)
	{
		primes[size] = i;
		if(is_prime(i, primes))
		{
			++c;
			primes[size++] = i;
			
		}
	}
	//printf("size : %d\n", size);
	return c;
}
int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	
	clock_gettime(CLOCK_REALTIME, &start);	
	int c = count_primes(n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
			   
	printf("# of primes : %d\n", c);
}

/*
// version 5
$ ./a.out
time 0.042440 
# of primes : 9592
$ ./a.out
time 0.034959 
# of primes : 9592
$ ./a.out
time 0.070577 
# of primes : 9592
$ ./a.out
time 0.037370 
# of primes : 9592
$ ./a.out
time 0.047792 
# of primes : 9592
*/
/*
// version 6
$ ./a.out
time 0.600052 
# of primes : 9592
$ ./a.out
time 0.575256 
# of primes : 9592
$ ./a.out
time 0.590815 
# of primes : 9592
*/
/*
// version 7
$ ./a.out
time 0.015171 
# of primes : 9656
$ ./a.out
time 0.011671 
# of primes : 9656
$ ./a.out
time 0.011712 
# of primes : 9656

*/
/*
// version 8
time 0.017516 
# of primes : 9592
$ ./a.out
time 0.013990 
# of primes : 9592
$ ./a.out
time 0.014047 
# of primes : 9592
*/

/*
// version 9
./a.out
time 0.015016 
# of primes : 9592
$ ./a.out
time 0.017297 
# of primes : 9592
$ ./a.out
time 0.015063 
# of primes : 9592
$ ./a.out
time 0.016737 
# of primes : 9592
*/

/*
$ ./a.out
time 0.009625 
# of primes : 9592
$ ./a.out
time 0.020876 
# of primes : 9592
$ ./a.out
time 0.009357 
# of primes : 9592
$ ./a.out
time 0.010270 
# of primes : 9592
$ ./a.out
time 0.009837 
# of primes : 9592

*/
