#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
// Bentley's rule for looping
// 1. code movement out of the loop
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif



#if 0
// version 8
int is_prime(int n, int primes[], int size)
{
	int factor;
	// order of eval of operands is not defined in C and C++
	// a[i] = i++; // undefined
	// for(int i = 0; i < size && (factor = primes[i]) * factor <= n ; ++i)
	for(int i = 0, factor = primes[i]; i < size && factor * factor <= n ;
			 ++i, factor = primes[i])
	{
		if(n % factor == 0)
		{
			return 0;
		}
	}
	return 1;
}
int count_primes(int n)
{
	int primes[10000];
	int size = 0;
	int c = 1; // count 2 as a prime
	for(int m = 3; m <= n; m += 2)
	{
		if(is_prime(m, primes, size))
		{
			++c;
			primes[size++] = m;
		}
	}
	return c;
}
#endif
// version 9
int is_prime(int n, int primes[], int size)
{
	int factor;
	// order of eval of operands is not defined in C and C++
	// a[i] = i++; // undefined
	// for(int i = 0; i < size && (factor = primes[i]) * factor <= n ; ++i)
	for(int i = 0; i < size  ;  ++i)
	{
		factor = primes[i];
		if(factor * factor > n)
		{
			return 1;
		}
		if(n % factor == 0)
		{
			return 0;
		}
	}
	return 1;
}
int count_primes(int n)
{
	int primes[10000];
	int size = 0;
	int c = 1; // count 2 as a prime
	for(int m = 3; m <= n; m += 2)
	{
		if(is_prime(m, primes, size))
		{
			++c;
			primes[size++] = m;
		}
	}
	return c;
}

int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	

	printf("%d\n", count_primes(n));
	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}




/*
// version 5
$ ./a.out
9592
time 0.039367 
$ ./a.out
9592
time 0.049805 
$ ./a.out
9592
time 0.041031 
$ ./a.out
9592
time 0.044243 
*/
/*
// version 6
$ ./a.out
9592
time 0.642990 
$ ./a.out
9592
time 0.632482 
$ ./a.out
9592
time 0.656577 
*/
/*
// version 7
$ ./a.out
9592
time 0.013064 
$ ./a.out
9592
time 0.011715 
$ ./a.out
9592
time 0.011585 
$ ./a.out
9592
time 0.012166 
*/
/*
// version 8
./a.out
9592
time 0.021627 
$ ./a.out
9592
time 0.011475 
$ ./a.out
9592
time 0.022964 
$ ./a.out
9592
time 0.011987 
*/
/*
// version 9
./a.out
9592
time 0.014653 
$ ./a.out
9592
time 0.014275 
$ ./a.out
9592
time 0.014029 
$ ./a.out
9592
time 0.015082 
*/
