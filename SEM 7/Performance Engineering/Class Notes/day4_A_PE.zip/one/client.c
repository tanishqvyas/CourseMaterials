#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "list.h"
void myswap(int *p, int *q)
{
	int temp = *p; *p = *q; *q = temp;
}
void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = i;
	}
	int j;
	for(int i = 0; i < n / 2; ++i)
	{
		j = rand() % (n - i) + i;
		myswap(&a[i], &a[j]);
	}
	
}
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
int main()
{
	list_t l;
	init_list(&l);
	int a[10000];
	int n = 10000;
	
	fill(a, n);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	
	for(int i = 0; i < n; ++i)
	{
		insert_list(&l, a[i]);
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	deinit_list(&l);
	
}
// C++ : random_shuffle : shuffles the elements of an array in linear time
// generate random numbers from 0 to n - 1
// all numbers should be present
// numbers have to be unique

// calling rand , check for existence of the number, then filling an array
//	very inefficient

// fill the array from 0 to n - 1; shuffle it 


/*
time 0.244612 
$ ./a.out
time 0.293463 
$ ./a.out
time 0.236263 
$ ./a.out
time 0.235645 
$ ./a.out
time 0.256197 
*/

