#include <stdio.h>
#include <stdlib.h>
#include "list.h"
// change the list :
//	have two additional pointers
//	one : points to the whole block
//	another : points to the next block to be used

// deletion cannot be supported efficiently

// or
//	create a linked list of free blocks
//	use it to allocate and deallocate
//	support any # of insertions and deletions


void init_list(list_t *ptr_list)
{
	ptr_list->head_ = 0;
}

void deinit_list(list_t *ptr_list)
{
/*
	node_t* pres = ptr_list->head_;
	node_t* prev = 0;
	while(pres)
	{
		prev = pres;
		pres = pres->link_;
		free(prev);
	}
	ptr_list->head_ = 0;
*/
	
}

// ordered list 
// predicate : <
// - insert into empty list
// - insertion in the beginning
// - insertion in the middle
// - insertion at the end

#define ALLOC(x) (x*)malloc(sizeof(x) * MAX)
node_t* make_node_(int key)
{
#if 0
	static node_t* ptr = ALLOC(node_t);
	static node_t* temp = ptr; 
	temp->key_ = key;
	return temp++;
#endif

	static int first = 1;
	static node_t* ptr;
	static node_t* temp;
	if(first)
	{
		ptr = ALLOC(node_t);
		temp = ptr;
		first = 0;
	}
	temp->key_ = key;
	return temp++;
}

void insert_list(list_t *ptr_list, int key)
{
	node_t *temp = make_node_(key);
	// empty list
	if(! ptr_list->head_)
	{
		ptr_list->head_ = temp;
		temp->link_ = 0;
	}
	else
	{
		node_t *prev = 0;
		node_t *pres = ptr_list->head_;
		while(pres && pres->key_ < key)
		{
			prev = pres;
			pres = pres->link_;
		}
		if(!prev)
		{
			ptr_list->head_ = temp;
		}
		else 
		{
			prev->link_ = temp;
		}
		temp->link_ = pres;
	}		
}


void disp_list(const list_t *ptr_list)
{
	node_t* temp = ptr_list->head_;
	while(temp)
	{
		printf("%d ", temp->key_);
		temp = temp->link_;
	}
	printf("\n");
}
