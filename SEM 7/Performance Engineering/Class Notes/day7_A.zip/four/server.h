#ifndef SERVER_H
#define SERVER_H
#define MAX 1024
extern int c;
void fill(int a[], int n);
void disp(int a[], int n);
void mysort(int a[], int l, int r);
int is_sorted(int a[], int n);
#endif

