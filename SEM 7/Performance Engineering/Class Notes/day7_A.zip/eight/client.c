#include <stdio.h>
#include "server.h"

int main()
{
	int n = MAX;
	printf("# of comparisons : %d\n", count(n));
}
