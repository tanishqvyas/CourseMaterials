#include <stdio.h>
#include <stdlib.h>
#include "server.h"


#if 0
// Jon Bentley :
//	indices : 0 .. n - 1
// are changed : 1 .. n
int count(int n)
{
	if(n <= 1) return 0;
	int m = rand() % n + 1;
	return (n - 1) + count(m - 1) + count(n - m);
		
}
#endif

// all possible partitions
// find the average
// O(3^n) - NP
int count(int n)
{
	if(n <= 1) return 0;
	int c = 0;
	for(int m = 1; m <= n; ++m)
	{
		c += (n - 1) + count(m - 1) + count(n - m);
	}
	return c / n; 
		
}






