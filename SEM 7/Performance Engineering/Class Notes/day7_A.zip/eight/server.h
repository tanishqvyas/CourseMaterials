#ifndef SERVER_H
#define SERVER_H
#define MAX 1024

// # of comparisons while sorting an array of n elements by quicksort

int count(int n); 
#endif

