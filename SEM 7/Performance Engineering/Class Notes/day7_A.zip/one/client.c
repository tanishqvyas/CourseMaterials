#include <stdio.h>
#include "server.h"

int main()
{
	int n = 9;
	int a[n];
	fill(a, n);
	mysort(a, 0, n-1);
	disp(a, n);
	printf("sorted : %d\n", is_sorted(a, n));
}
