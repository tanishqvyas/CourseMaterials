#include <stdio.h>
#include <stdlib.h>
#include "server.h"

 

 
#if 0
// replace qsort by count
// no more global variable
// pass a single arg to partition
// check this ?
int partition(int n)
{
	int m = rand() % n;
	c += n - 1;
	return m;
}


void count(int n)
{
	if(n > 1)
	{
		int m = partition(n);
		count(m - 1);
		count(n - m);
	}	
}
#endif

// Jon Bentley :
//	indices : 0 .. n - 1
// are changed : 1 .. n
int count(int n)
{
	if(n <= 1) return 0;
	int m = rand() % n + 1;
	return (n - 1) + count(m - 1) + count(n - m);
		
}






