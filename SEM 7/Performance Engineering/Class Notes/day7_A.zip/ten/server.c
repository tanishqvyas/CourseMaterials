#include <stdio.h>
#include <stdlib.h>
#include "server.h"



#if 0
// all possible partitions
// find the average
// O(3^n) - NP
int count(int n)
{
	if(n <= 1) return 0;
	int c = 0;
	for(int m = 1; m <= n; ++m)
	{
		c += (n - 1) + count(m - 1) + count(n - m);
	}
	return c / n; 
		
}

#endif

#if 0
// DP:
//	all possible array length
//		all possible partitions
int count(int n)
{
	int t[n + 1];
	t[0] = 0;
	// vary size
	for(int k = 1; k <= n; ++k)
	{
		int c = 0;
		// vary partition
		for(int m = 1; m <= k; ++m)
		{
			c += (k - 1) + t[m - 1] + t[k - m];
		}
		t[k] = c/k;
	}
	return t[n];
		
}
#endif

int count(int n)
{
	int t[n + 1];
	t[0] = 0;
	// vary size
	for(int k = 1; k <= n; ++k)
	{
		int c = 0;
		// vary partition
		for(int m = 1; m <= k; ++m)
		{
			c +=  2 * t[m - 1];
		}
		t[k] = (k - 1) + c/k;
	}
	return t[n];
}
/*
k = 4
	t[0] + t[3]
	t[1] + t[2]
	t[2] + t[1]
	t[3] + t[0]
*/



