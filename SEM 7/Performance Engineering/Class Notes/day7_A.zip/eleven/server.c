#include <stdio.h>
#include <stdlib.h>
#include "server.h"



// moving invariant out of the loop
int count(int n)
{
	int t[n + 1];
	t[0] = 0;
	// vary size
	int c = 0;
	for(int k = 1; k <= n; ++k)
	{
		c +=  2 * t[k - 1];
		t[k] = (k - 1) + c/k;
	}
	return t[n];
}

/*
k : A3 = A2 + 1
c : B3 = B2 + 2 * C2
t[k] : C3 = (A3 - 1) + B3/A3

*/

