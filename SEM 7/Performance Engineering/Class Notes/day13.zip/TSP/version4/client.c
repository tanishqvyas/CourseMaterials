#include <stdio.h>
#include "server.h"
#include <stdlib.h>
#include <math.h>
#include <time.h>
// index count from 1
// index 0 not used - there is sentinel


double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
int main()
{
	int n = 10000;
	point_t pt[n+1];
	int soln[n+1];
	init_points(pt, n);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	find_soln(pt, soln, n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));	printf("ok : %d\n", is_correct(soln, n));
	
}

/*
version 2:
./a.out
time 3.396750 
ok : 1
$ ./a.out
time 3.347338 
ok : 1
$ ./a.out
time 3.225959 
ok : 1
$ ./a.out
time 3.272883 
ok : 1

*/
/*
avoid recomputation of dist
there is little or no improvement
version 3:
time 3.273775 
ok : 1
$ ./a.out
time 3.295745 
ok : 1
$ ./a.out
time 3.267544 
ok : 1
$ ./a.out
time 3.638236 
ok : 1

*/
/*
removed square root;
compared squares instead
// version 4:
$ ./a.out
time 2.036051 
ok : 1
$ ./a.out
time 2.047743 
ok : 1
$ ./a.out
time 2.110809 
ok : 1
$ ./a.out
time 2.020691 
ok : 1
*/
