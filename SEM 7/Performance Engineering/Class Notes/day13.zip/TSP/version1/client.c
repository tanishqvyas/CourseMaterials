#include <stdio.h>
#include "server.h"
// index count from 1
// index 0 not used - there is sentinel

int main()
{
	int n = 10;
	point_t pt[n+1];
	// init array of pointers
	init_points(pt, n);
	//  soln : sequence of indices
	disp_points(pt, n);
	find_soln(pt, n);
	// disp_soln() ?
	// is_correct() ?
	
}
