#ifndef SERVER_H
#define SERVER_H
#define MAX 10000
struct point
{
	double x;
	double y;
};
typedef struct point point_t;

void init_points(point_t pt[], int n);
void disp_points(point_t pt[], int n);
void find_soln(point_t pt[], int n);

#endif

