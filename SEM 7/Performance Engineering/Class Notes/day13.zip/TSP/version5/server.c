#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "server.h"

void init_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		pt[i].x = rand() % 1000;
		pt[i].y = rand() % 1000;
	}
}

void disp_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		printf("x : %0.2lf y : %0.2lf\n", pt[i].x, pt[i].y);
	}
}

double find_dist_sq(point_t a, point_t b)
{
	return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

void init_array(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = 0;
	}
}
#if 0
// version 4
void find_soln(point_t pt[], int soln[], int n)
{
	int visited[n + 1];
	init_array(visited, n);
	int current = 1;
	visited[current] = 1;
	soln[1] = current;
	for(int i = 2; i <= n; ++i)
	{
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		for(int j = 1; j <= n; ++j)
		{
			if(!visited[j])
			{
				dist = find_dist_sq(pt[current], pt[j]);
				if(dist < min_dist)
				{
					min_dist = dist;
					min_pt = j;
				}
			}
		}
//		printf("%d -> %d\n", current, min_pt);
		current = min_pt;
		visited[current] = 1;
		soln[i] = current; 
	}
//	printf("%d -> %d\n", current, 1);
}
#endif

// version 5:
void disp_soln(int soln[], int n);
void myswap(int *p, int *q)
{
	int temp = *p;
	*p = *q;
	*q = temp;
}
/*
void find_soln(point_t pt[], int soln[], int n)
{
	int unvisited[n + 1];
	int current;
 	for(int i = 1; i <= n; ++i)
 	{
 		unvisited[i] = i;
 	}
	soln[1] = 1;
	for(int i = 2; i <= n; ++i)
	{
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		current = unvisited[i - 1];
		// first i - 1 elements are visited
		for(int j = i; j <= n; ++j)
		{
				dist = find_dist_sq(pt[current], pt[unvisited[j]]);
				if(dist < min_dist)
				{
					min_dist = dist;
					min_pt = j;
				}
		}
		soln[i] = unvisited[min_pt];
		myswap(&unvisited[i], &unvisited[min_pt]); 
	}
	//disp_soln(soln, n);
	//disp_soln(unvisited, n);
}
*/
void find_soln(point_t pt[], int soln[], int n)
{
	int current;
 	for(int i = 1; i <= n; ++i)
 	{
 		soln[i] = i;
 	}
	for(int i = 2; i <= n; ++i)
	{
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		current = soln[i - 1];
		// first i - 1 elements are visited
		for(int j = i; j <= n; ++j)
		{
				dist = find_dist_sq(pt[current], pt[soln[j]]);
				if(dist < min_dist)
				{
					min_dist = dist;
					min_pt = j;
				}
		}
		myswap(&soln[i], &soln[min_pt]); 
	}
}

// 1 2 3 4 5 6 
// ...
// 1 3 : 2 4 5 6
void disp_soln(int soln[], int n)
{
	for(int i = 1; i < n; ++i)
	{
		printf("%d -> %d\n", soln[i], soln[i+1]);
	}
	printf("%d -> %d\n", soln[n], soln[1]);
}
int is_all(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] == 0)
			return 0;
	}
	return 1;
}
int is_correct(int soln[], int n)
{
	int temp[n+1];
	init_array(temp, n);
	for(int i = 1; i <= n; ++i)
	{
		temp[soln[i]] = 1;
	}
	return is_all(temp, n);
}



