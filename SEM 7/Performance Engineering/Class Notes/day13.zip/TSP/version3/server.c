#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "server.h"

void init_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		pt[i].x = rand() % 1000;
		pt[i].y = rand() % 1000;
	}
}

void disp_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		printf("x : %0.2lf y : %0.2lf\n", pt[i].x, pt[i].y);
	}
}

double find_dist(point_t a, point_t b)
{
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

void init_array(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = 0;
	}
}

void find_soln(point_t pt[], int soln[], int n)
{
	int visited[n + 1];
	init_array(visited, n);
	int current = 1;
	visited[current] = 1;
	soln[1] = current;
	// i -  1 nodes have been selected; ith node to be picked up
	for(int i = 2; i <= n; ++i)
	{
		// node closest to the current
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		for(int j = 1; j <= n; ++j)
		{
			if(!visited[j])
			{
				// version 3: avoid recomputation of dist
				dist = find_dist(pt[current], pt[j]);
				if(dist < min_dist)
				{
					min_dist = dist;
					min_pt = j;
				}
			}
		}
//		printf("%d -> %d\n", current, min_pt);
		current = min_pt;
		visited[current] = 1;
		soln[i] = current; 
	}
//	printf("%d -> %d\n", current, 1);
}

void disp_soln(int soln[], int n)
{
	for(int i = 1; i < n; ++i)
	{
		printf("%d -> %d\n", soln[i], soln[i+1]);
	}
	printf("%d -> %d\n", soln[n], soln[1]);
}
int is_all(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] == 0)
			return 0;
	}
	return 1;
}
int is_correct(int soln[], int n)
{
	int temp[n+1];
	init_array(temp, n);
	for(int i = 1; i <= n; ++i)
	{
		temp[soln[i]] = 1;
	}
	return is_all(temp, n);
}



