#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "server.h"

void init_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		pt[i].x = rand() % 1000;
		pt[i].y = rand() % 1000;
	}
}

void disp_points(point_t pt[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		printf("x : %0.2lf y : %0.2lf\n", pt[i].x, pt[i].y);
	}
}

double find_dist_sq(point_t a, point_t b)
{
	return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

void init_array(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		a[i] = 0;
	}
}


void disp_soln(int soln[], int n);
void myswap(int *p, int *q)
{
	int temp = *p;
	*p = *q;
	*q = temp;
}

// version 7:
// compute xdiff ^ 2
// only if required compute ydiff ^ 2
void find_soln(point_t pt[], int soln[], int n)
{
	int unvisited[n + 1];
	int current;
 	for(int i = 1; i <= n; ++i)
 	{
 		unvisited[i] = i;
 	}
	soln[1] = 1;
	for(int i = 2; i <= n; ++i)
	{
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		current = unvisited[i - 1];
		double x = pt[current].x;
		double y = pt[current].y;
		// first i - 1 elements are visited
		for(int j = i; j <= n; ++j)
		{
				int jj = unvisited[j];
				
				dist = (x - pt[jj].x) * (x - pt[jj].x); 
				if(dist < min_dist)
				{
					dist += (y - pt[jj].y) * (y - pt[jj].y);
					if(dist < min_dist)
					{
						min_dist = dist;
						min_pt = j;
					}
				}
		}
		soln[i] = unvisited[min_pt];
		int temp = unvisited[i]; 
		unvisited[i] = unvisited[min_pt];
		unvisited[min_pt] = temp;
	}
}

						
#if 0

void find_soln(point_t pt[], int soln[], int n)
{
	int current;
 	for(int i = 1; i <= n; ++i)
 	{
 		soln[i] = i;
 	}
	for(int i = 2; i <= n; ++i)
	{
		double min_dist = DBL_MAX;
		int min_pt;
		double dist;
		current = soln[i - 1];
		// first i - 1 elements are visited
		for(int j = i; j <= n; ++j)
		{
				dist = find_dist_sq(pt[current], pt[soln[j]]);
				if(dist < min_dist)
				{
					min_dist = dist;
					min_pt = j;
				}
		}
		myswap(&soln[i], &soln[min_pt]); 
	}
}
#endif
// 1 2 3 4 5 6 
// ...
// 1 3 : 2 4 5 6
void disp_soln(int soln[], int n)
{
	for(int i = 1; i < n; ++i)
	{
		printf("%d -> %d\n", soln[i], soln[i+1]);
	}
	printf("%d -> %d\n", soln[n], soln[1]);
}
int is_all(int a[], int n)
{
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] == 0)
			return 0;
	}
	return 1;
}
int is_correct(int soln[], int n)
{
	int temp[n+1];
	init_array(temp, n);
	for(int i = 1; i <= n; ++i)
	{
		temp[soln[i]] = 1;
	}
	return is_all(temp, n);
}



