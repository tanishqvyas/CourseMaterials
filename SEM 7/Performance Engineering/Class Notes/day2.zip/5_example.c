// 
#include <stdio.h>

double what(double x, int n)
{
	double s = 1.0;
	long p = 1;
	long f = 1;
	int sign = -1;
	for(long i = 1; i <= n; ++i)
	{
		#if 0
//		p *= x;
		p *= x;
		f *= i;
		s += sign * (double)p / (double)f;
		sign = -sign;
		#endif
		#if 1
		p *= sign *x;
		f *= i;
		s +=  (double)p / (double)f;
		//sign = -sign;
		#endif
		
	}
	return s;
}
// sigma(x^i/i!)  : 0 <= i <= n; i is an integer 


int main()
{
	double x;
	int n;
	scanf("%lf %d", &x, &n);
	double res = what(x, n);
	printf("res : %lf\n", res);
}