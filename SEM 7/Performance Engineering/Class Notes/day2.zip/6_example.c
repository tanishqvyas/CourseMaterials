#include <stdio.h>

int main()
{
	int h;
	int t;
	int u;
	int hc;
	int tc;
	int uc;
	int n;
	#if 0
	for(int h = 0; h < 10; ++h)
	{
		for(int t = 0; t < 10; ++t)
		{
			for(int u = 0; u < 10; ++u)
			{
				n = h * 100 + t * 10 + u;
				hc = h * h * h;
				tc = t * t * t;
				uc = u * u * u;
				if(n == hc + tc + uc)
				{
					printf("%d\n", n);
				}
			}
		}
	}
	#endif
	for(int h = 0; h < 10; ++h)
	{
		hc = h * h * h;
		for(int t = 0; t < 10; ++t)
		{
			tc = t * t * t;
			for(int u = 0; u < 10; ++u)
			{
				n = h * 100 + t * 10 + u;
				uc = u * u * u;
				if(n == hc + tc + uc)
				{
					printf("%d\n", n);
				}
			}
		}
	}
}