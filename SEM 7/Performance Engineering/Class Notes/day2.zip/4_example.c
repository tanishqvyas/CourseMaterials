// 
#include <stdio.h>

double what(double x, int n)
{
	double s = 0.0;
	for(int i = 0; i <= n; ++i)
	{
		long p = 1;
		for(int j = 1; j <= i; ++j)
		{
			p *= x;
		} // p is x^i  i : 0, 1, ..., n 
		long f = 1;
		for(int j = 1; j <= i; ++j)
		{
			f *= j;
		}
		// f : i!  i : 0, 1, ..., n 
		s += (double)p / (double)f;
	}
	return s;
}
// sigma(x^i/i!)  : 0 <= i <= n; i is an integer 


int main()
{
	double x;
	int n;
	scanf("%lf %d", &x, &n);
	double res = what(x, n);
	printf("res : %lf\n", res);
}