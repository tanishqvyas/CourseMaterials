#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
// ijk
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif

#define SIZE 256

void init(int n; int x[n][n], int n)
{
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			x[i][j] = rand() % 10000;
		}
	}
}
void init_res(int n; int x[n][n], int n)
{
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			x[i][j] = 0;
		}
	}
}
void mul(int n; int a[n][n], int b[n][n], int c[n][n], int n)
{
	int i; int j; int k;
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			for(int k = 0; k < n; ++k)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
}

int main()
{
	int a[SIZE][SIZE];
	int b[SIZE][SIZE];
	int c[SIZE][SIZE];
	init(a, SIZE);
	init(b, SIZE);
	init_res(c, SIZE);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	mul(a, b, c, SIZE);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}
/*
D:\ a
time 0.094561

D:\ a
time 0.098941

D:\ a
time 0.092968

D:\ a
time 0.095945

D:\ a
time 0.090943
*/