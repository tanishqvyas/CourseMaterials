#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
// jik
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif

#define SIZE 256

void init(int n; int x[n][n], int n)
{
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			x[i][j] = rand() % 10000;
		}
	}
}
void init_res(int n; int x[n][n], int n)
{
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			x[i][j] = 0;
		}
	}
}
void mul(int n; int a[n][n], int b[n][n], int c[n][n], int n)
{
	int i; int j; int k;
	for(int j = 0; j < n; ++j)
	{
		for(int i = 0; i < n; ++i)
		{
			for(int k = 0; k < n; ++k)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
		}
	}
}

int main()
{
	int a[SIZE][SIZE];
	int b[SIZE][SIZE];
	int c[SIZE][SIZE];
	init(a, SIZE);
	init(b, SIZE);
	init_res(c, SIZE);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	mul(a, b, c, SIZE);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}
/*
D:\ a
time 0.096364

D:\ a
time 0.100940

D:\ a
time 0.098940

D:\ a
time 0.099657

D:\ a
time 0.097947

D:\ a
time 0.097917
*/