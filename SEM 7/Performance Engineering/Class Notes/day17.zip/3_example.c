// max sum of a continuous subsequence
//	consider a subsequence (i..j)
//	if sum is -ve, take sum as 0
//	find the highest of the positive sums

#include <stdio.h>
struct seq_sum
{
	int l;
	int r;
	double s;
};
typedef struct seq_sum seq_sum_t;
seq_sum_t max3(seq_sum_t a, seq_sum_t b, seq_sum_t c)
{
	seq_sum_t res = a;
	if(b.s > res.s)
		res = b;
	if(c.s > res.s)
		res = c;
	return res;
}

// O(n logn)
seq_sum_t find_sum_(double a[], int l, int r)
{
	int m = (l + r) / 2;
	int curr_i = l;
	int curr_j = m + 1;
	double lmax;
	double rmax;
	double sum;
	if(l > r)
	{
		seq_sum_t res = {-1, -1, 0.0};
		return res;
	}
	if(l == r)
	{
		seq_sum_t res = {l, r, (a[l] > 0) ? a[l] : 0};
		return res;
	}
	
	// sum to the left of the mid point
	lmax = sum = 0.0;
	for(int i = m; i >= l; --i)
	{
		sum += a[i];
		if(sum > lmax)
		{
			lmax = sum;
			curr_i = i;
		}
	}
	// sum to the right of the midpoint
	rmax = sum = 0.0;
	for(int i = m + 1; i <= r; ++i)
	{
		sum += a[i];
		if(sum > rmax)
		{
			rmax = sum;
			curr_j = i;
		}
	}
	seq_sum_t s_l_r = { curr_i, curr_j, lmax + rmax };
	seq_sum_t s_l = find_sum_(a, l, m);
	seq_sum_t s_r = find_sum_(a, m + 1, r);
	return max3(s_l_r, s_l, s_r);
}

seq_sum_t find_sum(double a[], int n)
{
	return find_sum_(a, 0, n - 1);
}

int main()
{
	double a[] = { 31, -41, 59, 26, -53, 58, 97, -93, -23, 84};
	int n = 10;
	seq_sum_t res = find_sum(a, n);
	printf("l : %d r : %d sum : %lf\n", res.l, res.r, res.s);
}
