// maximum sum of a continuous subsequence
// if sum becomes negative, take it as 0
#include <stdio.h>
struct seq_sum
{
	int l;
	int r;
	double s;
};
typedef struct seq_sum seq_sum_t;
// quadratic
seq_sum_t find_sum(double a[], int n)
{
	double acc[n + 1];
	acc[0] = 0.0;
	for(int i = 1; i <= n; ++i)
	{
		acc[i] = acc[i-1] + a[i-1];
	}
	// 	double a[] = {31, -41, 59, 26, -53, 58, 97, -93, -23, 84};
	// acc       = {0, 31, -10, 49, ... }
	
	// acc[j] - acc[i] : ? subsequence sum


	double curr_max = 0.0;
	double curr_i = -1;
	double curr_j = -1;
	
	for(int i = 1; i <= n; ++i)
	{
		double s;;
		for(int j = i; j < n; ++j)
		{
			s = acc[j] - acc[i - 1];
			if(s > curr_max)
			{
				curr_max = s;
				curr_i = i - 1;
				curr_j = j - 1;
			}
		}
	}
	seq_sum_t res = { curr_i, curr_j, curr_max };
	return res;
}

int main()
{
	double a[] = {31, -41, 59, 26, -53, 58, 97, -93, -23, 84};
	int n  = 10;
	seq_sum_t s;
	s = find_sum(a, n);
	printf("left : %d right : %d sum : %lf\n", s.l, s.r, s.s);	
}
