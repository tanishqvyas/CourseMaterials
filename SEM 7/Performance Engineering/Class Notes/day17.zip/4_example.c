// max sum of a continuous subsequence
//	consider a subsequence (i..j)
//	if sum is -ve, take sum as 0
//	find the highest of the positive sums

#include <stdio.h>
struct seq_sum
{
	int l;
	int r;
	double s;
};
typedef struct seq_sum seq_sum_t;


// O(n logn)


seq_sum_t find_sum(double a[], int n)
{
	double curr_max = 0.0;
	int curr_i = -1;
	int curr_j = -1;
	int max_l = -1;
	int max_r = -1;
	double max_end = 0.0;
	
	for(int i = 0; i < n; ++i)
	{
		if(max_end + a[i] > 0)
		{
			max_end += a[i];
			max_r = i;
		}
		else
		{
			max_end = 0.0;
			max_l = i + 1;
		}
		if(max_end > curr_max)
		{
			curr_max = max_end;
			curr_i = max_l;	
			curr_j = max_r;
		}
		
	}
	seq_sum_t res = { curr_i, curr_j, curr_max };
	return res;
}

int main()
{
	double a[] = { 31, -41, 59, 26, -53, 58, 97, -93, -23, 84};
	int n = 10;
	seq_sum_t res = find_sum(a, n);
	printf("l : %d r : %d sum : %lf\n", res.l, res.r, res.s);
}
