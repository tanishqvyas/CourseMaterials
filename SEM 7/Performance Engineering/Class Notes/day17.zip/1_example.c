// max sum of a continuous subsequence
//	consider a subsequence (i..j)
//	if sum is -ve, take sum as 0
//	find the highest of the positive sums

#include <stdio.h>
struct seq_sum
{
	int l;
	int r;
	double s;
};
typedef struct seq_sum seq_sum_t;
// time complexity : cubic
seq_sum_t find_sum(double a[], int n)
{
	double s;
	double curr_max = 0.0;
	int curr_i = -1;
	int curr_j = -1;
	for(int i = 0; i < n; ++i)
	{
		for(int j = i; j < n; ++j)
		{
			s = 0.0;
			for(int k = i; k <= j; ++k)
			{
				s += a[k];
			}
			if(s > curr_max)
			{
				curr_max = s;
				curr_i = i;
				curr_j = j;
			}
		}
	}
	seq_sum_t res = {curr_i, curr_j, curr_max};
	return res;
}

int main()
{
	double a[] = { 31, -41, 59, 26, -53, 58, 97, -93, -23, 84};
	int n = 10;
	seq_sum_t res = find_sum(a, n);
	printf("l : %d r : %d sum : %lf\n", res.l, res.r, res.s);
}
