#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "list.h"

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
void myswap(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}
void fill(int a[], int n)
{
	// fill numbers from 0 to n - 1
	for(int i = 0; i < n; ++i)
	{
		a[i] = i;
	}
	// random_shuffle : linear
	int j;
	for(int i = 0; i < n / 2; ++i)
	{
		j = rand() % (n - i - 1) + i + 1; // i +  1 .. n - 1
		myswap(&a[i], &a[j]);
	}
}
// i : 40; n = 50
// 41 .. 49

int main()
{
	list_t l;
	init_list(&l);
	int a[MAX];
	int n = MAX;
	fill(a, n);
	#if 0
	for(int i = 0; i < 10; ++i)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
	#endif
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	for(int i = 0; i < n; ++i)
	{
		insert_list(&l, a[i]);
		// disp_list(&l);
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	deinit_list(&l);
	
}
// fill the array with numbers from 0 to n - 1
// fairly random
// elements should be unique
// elements should be distinct

/*
without the header node: allocate a node at a time
$ ./a.out
time 0.244114 
$ ./a.out
time 0.220371 
$ ./a.out
time 0.241296 
$ ./a.out
time 0.228813 
$ ./a.out
time 0.243649 
$ ./a.out
time 0.236258
*/
/*
without header; allocate a block togethre
$ ./a.out
time 0.215071 
$ ./a.out
time 0.238392 
$ ./a.out
time 0.221072 
$ ./a.out
time 0.229941 
$ ./a.out
time 0.235083
*/
 
