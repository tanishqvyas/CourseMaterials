#include <stdio.h>
#include <stdlib.h>
#include "list.h"

void init_list(list_t *ptr_list)
{
	ptr_list->head_ = 0;
}

void deinit_list(list_t *ptr_list)
{
	node_t* pres = ptr_list->head_;
	node_t* prev = 0;
	while(pres)
	{
		prev = pres;
		pres = pres->link_;
		free(prev);
	}
	ptr_list->head_ = 0;
}

// ordered list 
// predicate : <
// - insert into empty list
// - insertion in the beginning
// - insertion in the middle
// - insertion at the end

#define ALLOC(x) (x*)malloc(sizeof(x))
node_t* make_node_(int key)
{
	node_t* temp = ALLOC(node_t); 
	temp->key_ = key;
	// temp->link_ = 0; // ???
	return temp;
}

void insert_list(list_t *ptr_list, int key)
{
	node_t *temp = make_node_(key);
	// empty list
	if(! ptr_list->head_)
	{
		ptr_list->head_ = temp;
		temp->link_ = 0;
	}
	else
	{
		node_t *prev = 0;
		node_t *pres = ptr_list->head_;
//		while(pres && pres->key_ < temp->key_)
		while(pres && pres->key_ < key)
		{
			prev = pres;
			pres = pres->link_;
		}
		// beginning list
		if(!prev)
		{
			ptr_list->head_ = temp;
		}
		else // middle or end
		{
			prev->link_ = temp;
		}
		temp->link_ = pres;
	}		
}

// void delete_list(list_t *ptr_list, int key);
void disp_list(const list_t *ptr_list)
{
	node_t* temp = ptr_list->head_;
	while(temp)
	{
		printf("%d ", temp->key_);
		temp = temp->link_;
	}
	printf("\n");
}