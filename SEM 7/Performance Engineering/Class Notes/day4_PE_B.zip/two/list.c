// header node : one additional node in the beginning 
// insert code has become logically simple

#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#define ALLOC(x) (x*)malloc(sizeof(x))
node_t* make_node_(int key)
{
	node_t* temp = ALLOC(node_t); 
	temp->key_ = key;
	// temp->link_ = 0; // ???
	return temp;
}

// empty list will have one node 
void init_list(list_t *ptr_list)
{
	ptr_list->head_ = ALLOC(node_t);
	ptr_list->head_->link_ = 0;
	// key_ : ?
}

void deinit_list(list_t *ptr_list)
{
	node_t* pres = ptr_list->head_->link_;
	node_t* prev = 0;
	while(pres)
	{
		prev = pres;
		pres = pres->link_;
		free(prev);
	}
	ptr_list->head_->link_ = 0;
}

// ordered list 
// predicate : <
// - insert into empty list
// - insertion in the beginning
// - insertion in the middle
// - insertion at the end



void insert_list(list_t *ptr_list, int key)
{
	node_t *temp = make_node_(key);
	
	node_t *prev = ptr_list->head_;
	node_t *pres = prev->link_;
	while(pres && pres->key_ < key)
	{
		prev = pres;
		pres = pres->link_;
	}
	prev->link_ = temp;
	temp->link_ = pres;
			
}

// void delete_list(list_t *ptr_list, int key);
void disp_list(const list_t *ptr_list)
{
	node_t* temp = ptr_list->head_->link_;
	while(temp)
	{
		printf("%d ", temp->key_);
		temp = temp->link_;
	}
	printf("\n");
}