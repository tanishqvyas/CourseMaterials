//  search thro a sorted array
//  will have a sentinel

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define DEBUG 0
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = i;
	}
}
// linear search :
// return -1 if not found
int search(int a[], int n, int x)
{
	int i;
	a[n] = x;
	for(i = 0; a[i] < x; ++i)
	{
	}
	return (x == a[i] && i != n) ? i : -1; 
}

int main()
{
	int n = 10000;
	int a[n + 1];
	fill(a, n); // sorted
	int x;
	int res;
	int n2 = n + n;
	int count_not_found = 0;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	for(int i = 1; i <= 1000; ++i)
	{
		x = rand() % n2;	
		res = search(a, n, x);
		if(DEBUG)
		{
			if(res != -1 && a[res] != x)
			{
				printf("ERROR\n");
			}
		}
		if(DEBUG)
		{
			if(res == -1) 
				++count_not_found;
		}
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	if(DEBUG)
		printf("not found : %lf\n", 
			(double)count_not_found/n);
	
}
/*
./a.out
time 0.053123 
$ ./a.out
time 0.078371 
$ ./a.out
time 0.056038 
$ ./a.out
time 0.051110 
$ ./a.out
time 0.049965
*/


