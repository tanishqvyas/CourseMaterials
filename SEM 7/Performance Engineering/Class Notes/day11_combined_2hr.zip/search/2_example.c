//  search thro a sorted array
//  will have a sentinel

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define DEBUG 0
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
void fill(int a[], int n)
{
	for(int i = 0; i < n; ++i)
	{
		a[i] = i;
	}
}
// linear search :
// return -1 if not found
// n is  a multiple of 4
int search(int a[], int n, int x)
{
	int i = 0;
	a[n] = x;
	int step;
	// 5 10 15 20 25 30 35 40
	// 10
	while(1)
	{
		if(a[i] >= x)
		{
			step = 0;
			break;
		}
		if(a[i+1] >= x)
		{
			step = 1;
			break;
		}
		if(a[i+2] >= x)
		{
			step = 2;
			break;
		}
		if(a[i+3] >= x)
		{
			step = 3;
			break;
		}
		i += 4;
	}
	int index = i + step;
	return (index < n && a[index] == x) ? index : -1;
}

int main()
{
	int n = 10000;
	int a[n + 1];
	fill(a, n); // sorted
	int x;
	int res;
	int n2 = n + n;
	int count_not_found = 0;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	for(int i = 1; i <= 1000; ++i)
	{
		x = rand() % n2;	
		res = search(a, n, x);
		if(DEBUG)
		{
			if(res != -1 && a[res] != x)
			{
				printf("ERROR\n");
			}
		}
		if(DEBUG)
		{
			if(res == -1) 
				++count_not_found;
		}
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	if(DEBUG)
		printf("not found : %lf\n", 
			(double)count_not_found/n);
	
}
/*
./a.out
time 0.053123 
$ ./a.out
time 0.078371 
$ ./a.out
time 0.056038 
$ ./a.out
time 0.051110 
$ ./a.out
time 0.049965
*/
/*
ime 0.077438 
$ ./2_example 
time 0.071989 
$ ./2_example 
time 0.062441 
$ ./2_example 
time 0.065448 
$ ./2_example 
time 0.148620
*/

/*
// binary search
	l .. r
	m <- (l + r) / 2
	if l <= r and a[m] != x 
	try binary search
	sentinel ??
	
*/
