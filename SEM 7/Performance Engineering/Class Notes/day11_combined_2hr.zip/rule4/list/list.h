#ifndef LIST_H
#define LIST_H
struct node
{
	int key_;
	struct node* link_;
};
typedef struct node node_t;

struct list
{
	node_t* head_;
	node_t* tail_;
};
typedef struct list list_t;
void init(list_t *ptr_list);
void insert(list_t *ptr_list, int elem);
int is_sorted(const list_t *ptr_list);
#endif

