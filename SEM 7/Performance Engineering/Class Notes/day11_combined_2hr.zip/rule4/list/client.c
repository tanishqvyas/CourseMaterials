#include <stdio.h>
#include <stdlib.h>
#include "list.h"

int main()
{
	list_t l;
	init(&l);
	int n = 10000;
	
	for(int i = 0; i < n; ++i)
	{
		insert(&l, rand() % 10000);
	}
	
	printf("sorted : %d\n", is_sorted(&l));
}
