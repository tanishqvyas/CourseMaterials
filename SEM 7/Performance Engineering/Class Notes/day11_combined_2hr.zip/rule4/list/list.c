#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "list.h"
#if 0
// version 1
node_t* make_node(int key)
{
	node_t *temp = (node_t*) malloc(sizeof(node_t));
	temp->key_ = key;
	return temp;
}
void init(list_t *ptr_list)
{
	ptr_list->head_ = make_node(0);
	ptr_list->tail_ = make_node(0);
	ptr_list->head_->link_ = ptr_list->tail_;
	// link_ of tail_ node is not initialized
}

void insert(list_t *ptr_list, int key)
{
	node_t *temp = make_node(key);
	node_t* prev = ptr_list->head_;
	node_t* pres = prev->link_;
	while(pres != ptr_list->tail_ &&  pres->key_ < key)
	{
		prev = pres;
		pres = pres->link_;
	}
	prev->link_ = temp;
	temp->link_ = pres;
}

int is_sorted(const list_t *ptr_list)
{
	// empty list
	if(ptr_list->head_->link_ == ptr_list->tail_)
		return 1;
	else
	{
		node_t* prev = ptr_list->head_->link_;
		node_t* pres = prev->link_;
		while(pres != ptr_list->tail_ && prev->key_ <= pres->key_)
		{
			prev = pres;
			pres = pres->link_;
		}
		return pres == ptr_list->tail_;
	}
}
#endif

#if 0
// version 2
node_t* make_node(int key)
{
	node_t *temp = (node_t*) malloc(sizeof(node_t));
	temp->key_ = key;
	return temp;
}
void init(list_t *ptr_list)
{
	ptr_list->head_ = make_node(0);
	ptr_list->tail_ = make_node(INT_MAX);
	ptr_list->head_->link_ = ptr_list->tail_;
	// link_ of tail_ node is not initialized
}

void insert(list_t *ptr_list, int key)
{
	node_t *temp = make_node(key);
	node_t* prev = ptr_list->head_;
	node_t* pres = prev->link_;
	while(pres->key_ < key)
	{
		prev = pres;
		pres = pres->link_;
	}
	prev->link_ = temp;
	temp->link_ = pres;
}

int is_sorted(const list_t *ptr_list)
{
	// empty list
	if(ptr_list->head_->link_ == ptr_list->tail_)
		return 1;
	else
	{
		node_t* prev = ptr_list->head_->link_;
		node_t* pres = prev->link_;
		while(pres != ptr_list->tail_ && prev->key_ <= pres->key_)
		{
			prev = pres;
			pres = pres->link_;
		}
		return pres == ptr_list->tail_;
	}
}
#endif

// version 3
node_t* make_node(int key)
{
	node_t *temp = (node_t*) malloc(sizeof(node_t));
	temp->key_ = key;
	return temp;
}
void init(list_t *ptr_list)
{
	ptr_list->head_ = make_node(0);
	ptr_list->tail_ = make_node(INT_MAX);
	ptr_list->head_->link_ = ptr_list->tail_;
	// link_ of tail_ node is not initialized
}

void insert(list_t *ptr_list, int key)
{
	node_t *temp = make_node(key);
	node_t* p = ptr_list->head_;
	node_t* q ;
	while(1)
	{
		q = p->link_;
		if(q->key_ >= key)
		{
			temp->link_ = q;
			p->link_ = temp;
			break;
		}
		p = q->link_;
		if(p->key_ >= key)
		{
			temp->link_ = p;
			q->link_ = temp;
			break;
		}
	}

}

int is_sorted(const list_t *ptr_list)
{
	// empty list
	if(ptr_list->head_->link_ == ptr_list->tail_)
		return 1;
	else
	{
		node_t* prev = ptr_list->head_->link_;
		node_t* pres = prev->link_;
		while(pres != ptr_list->tail_ && prev->key_ <= pres->key_)
		{
			prev = pres;
			pres = pres->link_;
		}
		return pres == ptr_list->tail_;
	}
}


