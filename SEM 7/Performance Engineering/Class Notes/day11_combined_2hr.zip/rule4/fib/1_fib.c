// find the nth fib seq
// 0 1 1 2 3 5 8 13 21
// a 0   1   1  2
// b 1   1   2  3
// c <- a + b : 1  2 3 5
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
int main()
{
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	int n = 40;
	int a = 0;
	int b = 1;
	int c = a + b;
	for(int i = 4; i <= n; ++i)
	{
		a = b;
		b = c;
		c = a + b;
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	printf("%d\n", c);
}
