
// 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif

// find the nth fib seq
// 0 1 1 2 3 5 8 13 21
// a 0   1  3  8  21
// b 1   2  5  13  34 
int main()
{
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	int n = 40;
	int a = 0;
	int b = 1;
	for(int i = 2; i <= n/2; ++i)
	{
		a = a + b;
		b = a + b;
	}
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	printf("%d\n", b);
}
