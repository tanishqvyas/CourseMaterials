#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
// Bentley's rule for looping
// 1. code movement out of the loop
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif

#if 0
// version 3
int is_prime(int n)
{
	// how about floor(sqrt(n) + 0.5)?
	double sqrt_n = sqrt(n);
	for(int i = 2; i <= sqrt_n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif

// version 4
// avoid comparing floating point values
// be in the int domain
int is_prime(int n)
{
	for(int i = 2; i * i <= n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
int count_primes(int n)
{
	int c = 0;
	for(int m = 2; m <= n; ++m)
	{
		if(is_prime(m))
		{
			++c;
		}
	}
	return c;
}
int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	

	printf("%d\n", count_primes(n));
	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}


/*
version 3
$ ./a.out
9592
time 0.057445 
$ ./a.out
9592
time 0.048052 
$ ./a.out
9592
time 0.045795 
*/
/*
version 4
$ ./a.out
9592
time 0.043006 
$ ./a.out
9592
time 0.045272 
$ 
$ ./a.out
9592
time 0.043308 
*/





