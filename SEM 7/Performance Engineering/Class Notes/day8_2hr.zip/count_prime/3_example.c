#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
// Bentley's rule for looping
// 1. code movement out of the loop
double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
#if 0
// version 2
int is_prime(int n)
{
	for(int i = 2; i <= sqrt(n); ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif

// version 3
int is_prime(int n)
{
	double sqrt_n = sqrt(n);
	for(int i = 2; i <= sqrt_n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
int count_primes(int n)
{
	int c = 0;
	for(int m = 2; m <= n; ++m)
	{
		if(is_prime(m))
		{
			++c;
		}
	}
	return c;
}
int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	

	printf("%d\n", count_primes(n));
	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}

/*
// version 2
$ ./a.out
9592
time 0.123574 
$ ./a.out
9592
time 0.118010 
$ ./a.out
9592
time 0.137784 
*/
/*
version 3
$ ./a.out
9592
time 0.057445 
$ ./a.out
9592
time 0.048052 
$ ./a.out
9592
time 0.045795 
*/
/*
for i <- 2 to sqrt(n) do
	<stmt>

for i <- m to n step s do
	<stmt>
	
	how many times are m, n, s evaluated?
	can i be changed in the body of the loop?
*/






