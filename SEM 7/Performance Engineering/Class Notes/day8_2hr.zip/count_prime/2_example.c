#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}
#if 0
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
#endif
#if 0
// version 1
int is_prime(int n)
{
	for(int i = 2; i < n; ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}
#endif
int is_prime(int n)
{
	for(int i = 2; i <= sqrt(n); ++i)
	{
		if(n % i == 0)
		{
			return 0;
		}
	}
	return 1;
}

int count_primes(int n)
{
	int c = 0;
	for(int m = 2; m <= n; ++m)
	{
		if(is_prime(m))
		{
			++c;
		}
	}
	return c;
}
int main()
{
	int n = 100000;
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	

	printf("%d\n", count_primes(n));
	
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
}
/*
// version 1
$ ./a.out
9592
time 5.649900 
$ ./a.out
9592
time 5.500186 
$ ./a.out
9592
time 5.778362
*/
/*
// version 2
$ ./a.out
9592
time 0.123574 
$ ./a.out
9592
time 0.118010 
$ ./a.out
9592
time 0.137784 
*/

