#include <stdio.h>
// cstrings : use NULL char or '\0' or 0 as the sentinel
// 		sentinel : smallest character ; least ASCII value ; 0

#if 0
void mystrcpy(const char* src, char* dst)
{
	while(*src != '\0')
	{
		*dst = *src;
		++dst;
		++src;
	}
	*dst = '\0';
}
#endif
void mystrcpy(const char* src, char* dst)
{
#if 0
	while((*dst = *src) != '\0')
	{
		++dst;
		++src;
	}
#endif
	while((*dst++ = *src++))
		;
}

int mystrcmp(const char* lhs, const char* rhs)
{
	while(*lhs != '\0' && *rhs != '\0' && *lhs != *rhs)
	{
		++lhs;
		++rhs;
	}
	return *lhs - *rhs;
}

int main()
{
	char a[] = "pes";
	char b[10];
	mystrcpy(a, b);
	printf("a : %s\n", a);
	printf("b : %s\n", b);	
}

