#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

double time_elapsed(struct timespec start, struct timespec end)
{
	double t;
	t = (end.tv_sec - start.tv_sec);				   
	t += (end.tv_nsec - start.tv_nsec) * 0.000000001;  
	return t;
}

void init(int n; double a[][n], int n)
{
	for(int i = 0; i < n; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			a[i][j] = rand();
		}
	}
			
}
/*
void multiply(int n; double a[][n], double b[][n], double c[][n], int l, int m, int n)
{
	for(int i = 0; i < l; ++i)
	{
		for(int j = 0; j < n; ++j)
		{
			c[i][j] = 0.0;
			for(int k = 0; k < m; ++k)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
				
		}	
	}
}
*/
void multiply(int n; double a[][n], double b[][n], double c[][n], int l, int m, int n)
{
	for(int i = 0; i < l; ++i)
	{
		for(int k = 0; k < m; ++k)
		{
			//c[i][j] = 0.0;
			for(int j = 0; j < n; ++j)
			{
				c[i][j] += a[i][k] * b[k][j];
			}
				
		}	
	}
}
double c[256][256];

int main()
{
	int n = 256;
	double a[n][n];
	double b[n][n];
	init(a, n);
	init(b, n);
	struct timespec start;
	struct timespec end;
	clock_gettime(CLOCK_REALTIME, &start);	
	multiply(a, b, c, n, n, n);
	clock_gettime(CLOCK_REALTIME, &end);	
	printf("time %lf \n",
			   time_elapsed(start, end));
	printf("the end\n");
	
}
/*
D:\nsk\PE>a.exe
time 0.069960
the end

D:\nsk\PE>a.exe
time 0.073957
the end

D:\nsk\PE>a.exe
time 0.070955
the end

D:\nsk\PE>a.exe
time 0.066958
the end
*/
