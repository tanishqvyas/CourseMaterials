#ifndef LIST_H
#define LIST_H
struct node
{
	int key_;
	struct node* link_;
};
typedef struct node node_t;

struct list 
{
	node_t* head_;
};

typedef struct list list_t;
void init_list(list_t *ptr_list);
void insert_list(list_t *ptr_list, int key);
void disp_list(const list_t *ptr_list);
void deinit_list(list_t *ptr_list);
#endif
