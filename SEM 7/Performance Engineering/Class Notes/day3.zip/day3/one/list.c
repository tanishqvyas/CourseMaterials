// node based linked list implementation
#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#define ALLOC(x) (x*)malloc(sizeof(x))
void init_list(list_t *ptr_list) 
{
	ptr_list->head_ = NULL;
}
node_t* make_node_(int key)
{
	node_t *temp = ALLOC(node_t);
	temp->key_ = key;
	// temp->link_ = NULL; // NO
	return temp;
	
}
// boundary conditions :
// - empty
// - beginning
// - end 
// - middle

void insert_list(list_t *ptr_list, int key)
{
	node_t* temp = make_node_(key);
	// empty list
	if(ptr_list->head_ == NULL)
	{
		ptr_list->head_ = temp;
		temp->link_ = NULL;
	}
	else
	{
		node_t* prev = NULL; node_t* pres = ptr_list->head_;
//		while(pres != NULL && pres->key_ < temp->key_)
		while(pres != NULL && pres->key_ < key)
		{
			prev = pres;
			pres = pres->link_;
		}
		// beginning
		if(! prev )
		{
			ptr_list->head_ = temp;
		}
		else // middle or end
		{
			prev->link_ = temp;
		}
		temp->link_ = pres;
	}
}
	
void disp_list(const list_t *ptr_list) 
{
	node_t* temp = ptr_list->head_;
	while(temp)
	{
		printf("%d ", temp->key_);
		temp = temp->link_;
	}
	printf("\n");
}

void deinit_list(list_t *ptr_list) 
{
	node_t* pres = ptr_list->head_;
	node_t* prev = NULL;
	while(pres)
	{
		prev = pres;
		pres = pres->link_;
		free(prev);
	}

}

// think how free works ?
// if(prev != NULL) free(prev);  // not a good code 
// free(prev); // good code 

