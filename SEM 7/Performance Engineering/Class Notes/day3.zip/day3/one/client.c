#include <stdio.h>
#include "list.h"

int main()
{
	list_t l;
	init_list(&l);
	int a[] = {20, 10, 40, 30, 25};
	int n = 5;
	for(int i = 0; i < n; ++i)
	{
		insert_list(&l, a[i]);
		disp_list(&l);
	}
	deinit_list(&l);
}