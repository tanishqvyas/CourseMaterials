select * into  Company.Employee_Log from Company.Employee
where 1 > 2

alter table Company.Employee_Log 
add update_user varchar(20) not null, 
    update_date datetime not null default getdate();

Create or alter trigger Company.Employee_delete_trg 
on Company.Employee after delete as
begin

   insert into Company.Employee_Log (Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno, update_user, update_date)
   select Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno, suser_name(), getdate()
   from deleted D

end;

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('John', 'B', 'Smith', '223344556', '1965-01-09', '731 Fondren, Houston, TX', 'M', 100000, '333445555', 5);

select * from Company.Employee;

select * from Company.Employee_Log;

delete from Company.Employee where SSN = '223344556';

/* Views */

create view Company.vDepartment_Summary (Dno, Dname, Emp_Count, Avg_Sal)
as
select D.Dnumber,
       D.Dname,
       count(E.SSN),
	   AVG(E.Salary)
from Company.Employee E,
     Company.Department D
where D.Dnumber = E.Dno
group by D.Dnumber,
         D.Dname;

select * from Company.vDepartment_Summary D
where D.Dname = 'Research';

select * from Company.vDepartment_Summary D
where D.Avg_Sal > 35000;

insert into Company.vDepartment_Summary(Dno, Dname, Emp_Count, Avg_Sal)
values (5, 'Research', 10, 50000);

create view Company.vEmployee_Details (Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno, Dname)
as 
select E.Fname, E.Minit, E.Lname, E.SSN, E.Bdate, E.Address, E.Sex, E.Salary, E.Super_ssn, E.Dno, D.Dname
from Company.Employee E,
     Company.Department D
where E.Dno = D.Dnumber;

select * from Company.vEmployee_Details E
where E.Dname = 'Research';

insert into Company.vEmployee_Details(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('John', 'B', 'Smith', '223344556', '1965-01-09', '731 Fondren, Houston, TX', 'M', 100000, '333445555', 5);
