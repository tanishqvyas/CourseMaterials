insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('John', 'B', 'Smith', '123456789', '1965-01-09', '731 Fondren, Houston, TX', 'M', 30000, '333445555', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Franklin', 'T', 'Wong', '333445555', '1955-12-08', '638 Voss, Houston, TX', 'M', 40000, '888665555', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Alicia', 'J', 'Zelaya', '999887777', '1968-01-19', '3321 Castle, Spring, TX', 'F', 25000, '987654321', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Jennifer', 'S', 'Wallace', '987654321', '1941-06-20', '291 Berry, Bellaire, TX', 'F', 43000, '888665555', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Ramesh', 'K', 'Narayan', '666884444', '1962-09-15', '975 Fire Oak, Humble, TX', 'M', 38000, '333445555', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Joyce', 'A', 'English', '453453453', '1972-07-31', '5631 Rice, Houston, TX', 'F', 25000, '333445555', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('Ahmad', 'V', 'Jabbar', '987987987', '1969-03-29', '980 Dallas, Houston, TX', 'M', 25000, '987654321', null);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('James', 'E', 'Borg', '888665555', '1937-11-10', '450 Stone, Houston, TX', 'M', 55000, null, null);

select * from Company.Employee

insert into Company.Department(Dname, Dnumber, Mgr_ssn, Mgr_start_date)
values('Research', 5, '333445555', '1988-05-22');

insert into Company.Department(Dname, Dnumber, Mgr_ssn, Mgr_start_date)
values('Administration', 4, '987654321', '1995-01-01');

insert into Company.Department(Dname, Dnumber, Mgr_ssn, Mgr_start_date)
values('Headquarters', 1, '888665555', '1981-06-19');

select * from Company.Department;

insert into Company.Dept_Locations(DNumber, Dlocation)
values (1, 'Houston');

insert into Company.Dept_Locations(DNumber, Dlocation)
values (4, 'Stafford');

insert into Company.Dept_Locations(DNumber, Dlocation)
values (5, 'Bellaire');

insert into Company.Dept_Locations(DNumber, Dlocation)
values (5, 'Sugarland');

insert into Company.Dept_Locations(DNumber, Dlocation)
values (5, 'Houston');

select * from Company.Dept_Locations

Update Company.Employee set Dno = 1
where SSN = '888665555';

Update Company.Employee set Dno = 4
where SSN in ('987987987', '987654321', '999887777');

Update Company.Employee set Dno = 5
where Dno is null;

select * from Company.Employee;

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('ProductX', 1, 'Bellaire', 5);

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('ProductY', 2, 'Sugarland', 5);

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('ProductZ', 3, 'Houston', 5);

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('Computerization', 10, 'Stafford', 4);

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('Reorganization', 20, 'Houston', 1);

insert into Company.Project(Pname, Pnumber, Plocation, Dnum)
values ('Newbenefits', 30, 'Stafford', 4);

select * from Company.Project

insert into Company.Works_On (Essn, Pno, Hours)
values ('123456789', 1, 32.5);

insert into Company.Works_On (Essn, Pno, Hours)
values ('123456789', 2, 7.5);

insert into Company.Works_On (Essn, Pno, Hours)
values ('666884444', 3, 40);

insert into Company.Works_On (Essn, Pno, Hours)
values ('453453453', 1, 20);

insert into Company.Works_On (Essn, Pno, Hours)
values ('453453453', 2, 20);

insert into Company.Works_On (Essn, Pno, Hours)
values ('333445555', 2, 10);

insert into Company.Works_On (Essn, Pno, Hours)
values ('333445555', 3, 10);

insert into Company.Works_On (Essn, Pno, Hours)
values ('333445555', 10, 10);

insert into Company.Works_On (Essn, Pno, Hours)
values ('333445555', 20, 10);

insert into Company.Works_On (Essn, Pno, Hours)
values ('999887777', 30, 30);

insert into Company.Works_On (Essn, Pno, Hours)
values ('999887777', 10, 10);

insert into Company.Works_On (Essn, Pno, Hours)
values ('987987987', 10, 35);

insert into Company.Works_On (Essn, Pno, Hours)
values ('987987987', 30, 5);

insert into Company.Works_On (Essn, Pno, Hours)
values ('987987987', 10, 35);

insert into Company.Works_On (Essn, Pno, Hours)
values ('987654321', 30, 20);

insert into Company.Works_On (Essn, Pno, Hours)
values ('987654321', 20, 15);

insert into Company.Works_On (Essn, Pno, Hours)
values ('888665555', 20, null);

alter table Company.Works_On alter column Hours smallint null ;

delete from Company.Works_On where Essn = '888665555' and  
Pno = 20;

insert into Company.Works_On (Essn, Pno)
values ('888665555', 30);

insert into Company.Works_On (Essn, Pno, Hours)
values ('888665555', 30, null);

select * from Company.Works_On;

delete from Company.Works_On where Essn = '888665555' and  
Pno = 20;

insert into Company.Works_On (Essn, Pno, Hours)
values ('888665555', 20, null);

select * from Company.Works_On where Hours = null;

select * from Company.Works_On where Hours is null;

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('333445555', 'Alice', 'F', '1986-04-05', 'Daughter');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('333445555', 'Theodore', 'M', '1983-10-25', 'Son');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('333445555', 'Joy', 'F', '1958-05-03', 'Spouse');

alter table Company.Dependent add constraint Rel_Constraint
CHECK (Relationship in ('Spouse', 'Son', 'Daughter'));

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('987654321', 'Abner', 'M', '1942-02-28', 'Husband');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('987654321', 'Abner', 'M', '1942-02-28', 'Spouse');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('123456789', 'Michael', 'M', '1988-01-04', 'Son');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('123456789', 'Alice', 'F', '1988-12-30', 'Daughter');

insert into Company.Dependent(Essn,Dependent_name,Sex,Bdate,Relationship)
values ('123456789', 'Elizabeth', 'F', '1967-05-05', 'Spouse');

select * from Company.Dependent;

/* Update */

select * from Company.Employee 
where Dno = (select Dnumber from Company.Department
             where Dname = 'Research')

update Company.Employee set Salary = Salary * 1.1
where Dno = (select Dnumber from Company.Department
             where Dname = 'Research')

update Company.Employee set Salary = Salary / 1.1
where Dno = (select Dnumber from Company.Department
             where Dname = 'Research')
             
/* Delete */

select * from Company.Works_On where Pno = 30;

delete from Company.Project where Pname = 'Newbenefits';

sp_help [Company.Works_On];

alter table Company.Works_On 
   drop constraint FK__Works_On__Pno__74AE54BC;

alter table Company.Works_On 
   add constraint FK_Works_On_Pno foreign key (Pno) 
       references Company.Project(Pnumber) on delete cascade;
   

delete from Company.Project where Pname = 'Newbenefits';

select * from Company.Works_On where Pno = 30;

select * from Company.Employee;

Select TOP 5 * from Company.Employee;

SELECT E.Lname as Last_Name, E.Fname as First_Name, E.SSN, 
       E.Bdate as Date_of_birth
FROM Company.Employee as E
where E.Dno = 5;

SELECT distinct DL.Dlocation as Location
FROM Company.Dept_Locations as DL;

set dateformat DMY;

SELECT E.Lname as Last_Name, E.Fname as First_Name, E.SSN, 
       E.Bdate as Date_of_birth
FROM Company.Employee as E
where E.Bdate >= '31/01/1960';

SELECT E.Lname as Last_Name, E.Fname as First_Name, E.SSN, 
       E.Bdate as Date_of_birth
FROM Company.Employee as E
where E.Lname like '%a%';

SELECT E.Lname as Last_Name, E.Fname as First_Name, E.SSN, 
       E.Bdate as Date_of_birth, D.Dname as Department
FROM Company.Employee as E,
     Company.Department as D
where E.Dno = D.Dnumber;

/* cross product */

SELECT E.Lname as Last_Name, E.Fname as First_Name, E.SSN, 
       E.Bdate as Date_of_birth, D.Dname as Department
FROM Company.Employee as E,
     Company.Department as D;

/* Self join */

SELECT E.Lname as Emp_Last_Name, 
       E.Fname as Emp_First_Name, 
       E.SSN as Emp_SSN, 
	   E.Bdate as Emp_Date_of_birth, 
	   D.Dname as Department, 
	   S.Lname as Supervisor_Last_Name, 
	   S.Fname as Supervisor_First_Name
FROM Company.Employee as E,
     Company.Department as D,
	 Company.Employee as S
where E.Dno = D.Dnumber and
      S.SSN = E.Super_ssn
order by D.Dname,
         E.Lname;


/* Aggregate queries */

SELECT D.Dname as Department,
       count(E.SSN) as Employee_count,
	   avg(E.salary) as Average_Salary,
	   min(E.salary) as Minimum_salary,
	   max(E.salary) as Maximum_salary
FROM Company.Employee as E,
     Company.Department as D
where E.Dno = D.Dnumber
group by D.Dname
order by 2 desc;

SELECT D.Dname as Department,
       count(E.SSN) as Employee_count,
	   avg(E.salary) as Average_Salary
FROM Company.Employee as E,
     Company.Department as D
where E.Dno = D.Dnumber
group by D.Dname
having avg(E.salary) >= 35000
order by 2 desc;

SELECT D.Dname as Department,
       count(E.SSN) as Employee_count,
	   avg(E.salary) as Average_Salary
FROM Company.Employee as E,
     Company.Department as D
where E.Dno = D.Dnumber
group by D.Dname
having min(E.salary) >= 35000
order by 2 desc;

/* Employees making above average salary of their department */

SELECT E.Lname as Last_Name, 
       E.Fname as First_Name, 
	   E.SSN, 
       E.Bdate as Date_of_birth, 
	   E.Salary as Salary,
	   D.Dname as Department,
	   T.Avg_sal as Average_salary
FROM Company.Employee as E,
     Company.Department as D,
	 (select E2.Dno as Dept_no,
	         avg(E2.Salary) as Avg_sal
	  from Company.Employee E2
	  group by E2.Dno) as T
where E.Dno = D.Dnumber and 
      E.Dno = T.Dept_no and 
      E.Salary > T.Avg_sal;

