select * from Company.Employee;

WITH BIGDEPTS (Dno) AS
(	SELECT	E.Dno as Dno
	FROM	Company.EMPLOYEE E
	GROUP BY E.Dno
	HAVING	COUNT (*) > 2)
SELECT		E2.Dno, COUNT (*)
FROM		Company.EMPLOYEE E2
WHERE		E2.Salary >= 40000 AND E2.Dno IN 
                      (select Dno from BIGDEPTS)
GROUP BY E2.Dno;

/* case */

select * from Company.Employee;

UPDATE Company.EMPLOYEE SET	Salary = 
		CASE	WHEN Dno = 5 THEN Salary + 200
				WHEN Dno = 4 THEN Salary + 150
				WHEN Dno = 1 THEN Salary + 300
		END;

UPDATE Company.EMPLOYEE SET	Salary = 
		CASE	WHEN Dno = 5 THEN Salary - 200
				WHEN Dno = 4 THEN Salary - 150
				ELSE Salary - 300
		END;

/* Hierarchy */

WITH Direct_Reports(Manager_ID, Employee_ID, Employee_Level) AS   
(  
    SELECT E.Super_ssn, E.SSN, 0 AS Employee_Level  
    FROM Company.Employee E   
    WHERE E.Super_ssn IS NULL  
    UNION ALL
    SELECT E.Super_ssn, E.SSN, DR.Employee_Level + 1  
    FROM Company.Employee AS E
        INNER JOIN Direct_Reports AS DR  
        ON E.Super_ssn = DR.Employee_ID   
)  
SELECT Manager_ID, Employee_ID, Employee_Level   
FROM Direct_Reports
ORDER BY Employee_Level, Manager_ID;

select E.SSN, datediff (dd, E.Bdate, getdate()) as Age_Years
from Company.Employee E;

select datepart (Month, E.Bdate) as Month, 
       datename (Month, E.Bdate) as Month_Name,
	   '01/' + datepart (Month, E.Bdate) + '/' + datepart (yyyy, E.Bdate)
	   count(E.SSN) as Emp_Count
from Company.Employee E
group by datepart (Month, E.Bdate),
         datename (Month, E.Bdate)
order by 3 desc;


set dateformat DMY;

select datepart (Month, E.Bdate) as Month, 
       datename (Month, E.Bdate) as Month_Name,
	   dateadd(dd, -1, dateadd(mm,1,convert(date, '01/' + convert(varchar,datepart (Month, E.Bdate)) + '/' 
	   + convert(varchar,datepart (yyyy, E.Bdate)))))
from Company.Employee E
order by 1;

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('James', 'B', 'Smith', '223456789', '1965-01-09', '731 Fondren, Houston, TX', 'M', 30000, '453453453', 5);

