Create table Company.Budget (Dnumber smallint not null,
                             fiscal_year smallint not null,
							 Employee_Salary money not null,
							 Food_beverages money not null default 0,
							 constraint Budget_PK primary key (Dnumber, fiscal_year),
							 constraint Budget_FK1 foreign key  (Dnumber) 
							   references Company.Department(Dnumber));

select * from Company.Department;

insert into Company.Budget(Dnumber,fiscal_year,Employee_Salary)
values (5, 2020, 1000000)

Create or alter trigger Company.Employee_insert_trg on Company.Employee
after insert, update as
begin

declare @Budget money, @Total_Salary money;
declare @Msg varchar(255);
set @Budget = 0;
set @Total_Salary = 0;
set @Msg = '';

select @Total_Salary = sum(E.Salary)
from Company.Employee E, inserted I
where E.Dno = I.Dno;

select @Budget = B.Employee_Salary
from Company.Budget B,
     inserted I
where B.Dnumber = I.Dno and
      B.fiscal_year = year(getdate());

if (@Total_Salary > @Budget)
begin
   set @Msg = convert(varchar, @Total_Salary) + ' Exceeds allocated budget of ' + convert(varchar, @Budget);

   raiserror(@Msg, 1, 1);
   rollback;
end

   return;
end;

select dno, sum(salary) from Company.Employee
group by dno

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('John', 'B', 'Smith', '223344556', '1965-01-09', '731 Fondren, Houston, TX', 'M', 1000000, '333445555', 5);

insert into Company.Employee(Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary, Super_ssn, Dno)
values ('John', 'B', 'Smith', '223344556', '1965-01-09', '731 Fondren, Houston, TX', 'M', 100000, '333445555', 5);

select * from Company.Employee

update Company.Employee set Salary = 1000000 
where SSN = '223344556';

update Company.Employee set Salary = 200000 
where SSN = '223344556';

delete from Company.Employee where SSN = '223344556'