select * from Company.Employee E
where E.SSN like '__3%'

select * from Company.Employee E
where E.Salary between 30000 and 40000;

select * from Company.Employee E
where E.Salary not between 30000 and 40000;

select P.Pnumber, P.Pname
from Company.Project P,
     Company.Employee E,
	 Company.Works_On W
where W.Essn = E.SSN and 
      E.Lname = 'Smith' and 
	  E.Dno = P.Dnum
UNION 
select P.Pnumber, P.Pname
from Company.Project P,
     Company.Employee E,
	 Company.Department D
where P.Dnum = D.Dnumber and 
      D.Mgr_ssn = E.SSN and 
	  E.Lname = 'Smith';

select E.SSN
from Company.Employee E
intersect
select DP.Essn
from Company.Dependent DP

select E.SSN
from Company.Employee E
EXCEPT 
select DP.Essn
from Company.Dependent DP

create table Company.A (id smallint not null,
                        Description varchar(20) not null);

insert into Company.A (id, Description)
values (1, 'One');
insert into Company.A (id, Description)
values (2, 'Two');
insert into Company.A (id, Description)
values (3, 'Three');

select * from Company.A;

create table Company.B (id smallint not null,
                        Description varchar(20) not null);

insert into Company.B (id, Description)
select id, Description from Company.A;

insert into Company.A (id, Description)
values (11, 'Eleven');
insert into Company.A (id, Description)
values (12, 'Twelve');
insert into Company.A (id, Description)
values (13, 'Thirteen');

insert into Company.B (id, Description)
values (21, 'Twenty one');
insert into Company.B (id, Description)
values (22, 'Twenty two');
insert into Company.B (id, Description)
values (23, 'Twenty three');

select * from Company.A;
select * from Company.B;

/* left outer join */

select * from Company.A left outer join Company.B
on A.id = B.id;

/* right outer join */

select * from Company.A right outer join Company.B
on A.id = B.id;

/* full outer join */

select * from Company.A full outer join Company.B
on A.id = B.id;

/* inner join */

select * from Company.A inner join Company.B
on A.id = B.id;

select * from Company.A join Company.B
on A.id = B.id;

SELECT DISTINCT Pnumber 
FROM Company.Project 
WHERE Pnumber IN  ( SELECT Pnumber    
                    FROM Company.PROJECT, 
					     Company.DEPARTMENT, 
					     Company.EMPLOYEE    
					WHERE  Dnum = Dnumber AND   
					       Mgr_ssn = Ssn AND 
						   Lname = 'Smith' )  
			   OR  Pnumber IN  ( SELECT Pno    
			                     FROM Company.WORKS_ON, 
								      Company.EMPLOYEE    
								 WHERE Essn = Ssn AND 
								       Lname = 'Smith' ); 

/*********
SELECT DISTINCT Essn 
FROM Company.Works_On 
WHERE (Pno, Hours) IN ( SELECT Pno, Hours    
                        FROM Company.WORKS_ON    
						WHERE Essn = '123456789'); 
******/
SELECT Pno, Hours  
	   into #T 
       FROM Company.WORKS_ON    
	   WHERE Essn = '123456789';

SELECT DISTINCT W.Essn 
FROM Company.Works_On W,
     #T T
where W.Pno in (T.Pno) and 
      W.Hours in (T.Hours);

SELECT E.Lname, E.Fname 
FROM Company.EMPLOYEE E
WHERE E.Salary > ALL ( SELECT E2.Salary    
                       FROM Company.EMPLOYEE E2
					   WHERE E2.Dno = 5 );

/* Retrieve the name of each employee who has a dependent 
   with the same first name and is the same sex as the employee */
   
SELECT E.Fname, E.Lname 
FROM   Company.EMPLOYEE AS E 
WHERE E.Ssn IN ( SELECT D.Essn     
                 FROM Company.DEPENDENT AS D     
				 WHERE E.Fname = D.Dependent_name    AND 
				       E.Sex = D.Sex ); 

/* Correlated sub query */

SELECT E.Fname, E.Lname 
FROM Company.EMPLOYEE AS E  
WHERE EXISTS ( SELECT *     
               FROM Company.DEPENDENT AS D     
			   WHERE E.Ssn = D.Essn AND 
			         E.Sex = D.Sex  AND 
					 E.Fname = D.Dependent_name); 

SELECT E.Fname, E.Lname 
FROM Company.EMPLOYEE AS E  
WHERE NOT EXISTS ( SELECT *     
               FROM Company.DEPENDENT AS D     
			   WHERE E.Ssn = D.Essn AND 
			         E.Sex = D.Sex  AND 
					 E.Fname = D.Dependent_name); 

/* List of managers who have at least one dependent */

SELECT E.Fname, E.Lname 
FROM Company.EMPLOYEE E
WHERE EXISTS ( SELECT *     
               FROM Company.DEPENDENT DP    
			   WHERE E.Ssn = DP.Essn )  AND  EXISTS ( SELECT *     
			                                         FROM Company.DEPARTMENT D
													 WHERE E.Ssn = D.Mgr_ssn ); 

/* Retrieve the name of each employee who works on all the 
   projects controlled by department number 5 */

   SELECT E.Fname, E.Lname 
   FROM Company.EMPLOYEE E WHERE NOT EXISTS ( ( SELECT P.Pnumber        
                                                FROM   Company.PROJECT P
												WHERE  P.Dnum = 5)  EXCEPT 
												   ( SELECT W.Pno      
												     FROM Company.WORKS_ON W
													 WHERE E.Ssn = W.Essn) ); 