USE [DBMS]
GO

CREATE SCHEMA [Company] AUTHORIZATION [public]
GO

CREATE TYPE SSN FROM varchar(9) NOT NULL
GO

CREATE TABLE Company.Employee(
  Fname varchar(20) not null,
  Minit char(1) null,
  Lname varchar(20) not null,
  SSN SSN CHECK (SSN like replicate('[0-9]',9)),
  Bdate date not null CHECK (Bdate < getdate()),
  Address varchar(50) not null, 
  Sex varchar(1) null,
  Salary money not null,
  Super_ssn varchar(9) null CHECK (Super_ssn like replicate('[0-9]',9)),
  Dno smallint null,
  constraint Employee_PK primary key (SSN));

  set dateformat 'DMY';

  insert into Company.Employee(
  Fname, Minit, Lname, SSN, Bdate, Address, Sex, Salary,
  Super_ssn, Dno)
  values ('AAA', null, 'LLL', '012345678', '30/1/2020', 
  '1 MG Road, Bangalore', 'M', 20000, '000000000', null);

  select * from Company.Employee;

  sp_tables;

  select * from dbo.sysobjects where type = 'U';

  sp_help [Company.Employee];
  
Create table Company.Department(
  Dname varchar(50) not null,
  Dnumber smallint not null,
  Mgr_ssn varchar(9) null CHECK (Mgr_ssn like replicate('[0-9]',9)),
  Mgr_start_date date not null CHECK (Mgr_start_date < getdate()),
  constraint Department_PK primary key (Dnumber),
  constraint Dept_Mgr_FK foreign key (Mgr_ssn) 
      references Company.Employee(SSN) on delete set null);

insert into Company.Department(
  Dname, Dnumber, Mgr_ssn, Mgr_start_date)
  values('D1', 1, '012345678', '20/1/2020')


Create table Company.Dept_Locations
     (DNumber smallint not null,
      Dlocation varchar(20) not null,
	  constraint Dept_Locations_PK primary key (DNumber, Dlocation),
	  constraint Dept_loc_Dno_FK foreign key (DNumber) 
	      references Company.Department(Dnumber) on delete cascade);

Create table Company.Project(
      Pname varchar(50) not null,
	  Pnumber smallint not null primary key,
	  Plocation varchar(20) not null,
	  Dnum smallint null foreign key 
	       references Company.Department(Dnumber) on delete set null);

Create table Company.Works_On(
      Essn SSN CHECK (Essn like replicate('[0-9]',9)),
	  Pno smallint not null,
	  Hours smallint not null default 0,
	  primary key (Essn, Pno),
	  foreign key (Essn)
	       references Company.Employee(SSN) on delete cascade,
	  foreign key (Pno) references Company.Project(Pnumber));

Create table Company.Dependent
   (Essn SSN CHECK (Essn like replicate('[0-9]',9)),
    Dependent_name varchar(20) not null,
	Sex char(1) null CHECK (Sex in ('M', 'F')),
	Bdate date not null CHECK (Bdate < getdate()),
	Relationship varchar(20) not null,
	constraint Dependent_PK primary key (Essn, Dependent_name),
	constraint Dependent_Emp_FK foreign key (Essn)
	       references Company.Employee(SSN) on delete cascade);

ALTER TABLE Company.Employee ADD constraint Emp_Dept_FK 
foreign key (Dno) references Company.Department(Dnumber) on delete set null;

Create table Company.Employee_Docs(
      Essn SSN CHECK (Essn like replicate('[0-9]',9)),
	  Document_name varchar(20) not null,
	  Document_type varchar(10) not null,
	  Document_BLOB varbinary(max) null,
	  primary key (Essn, Document_name),
	  foreign key (Essn)
	       references Company.Employee(SSN) on delete cascade);

insert into Company.Employee_Docs(
      Essn, 
	  Document_name,
	  Document_type)
values ('012345678', '012345678 Picture', 'Photo');

update Company.Employee_Docs 
set Document_BLOB = BulkColumn from Openrowset( Bulk 'D:\temp\PES.JPG', Single_Blob) as Document_BLOB
where Essn='012345678'

select * from Company.Employee_Docs

declare @BlobData varbinary(max),
        @init int

SELECT @BlobData = Document_BLOB 
from Company.Employee_Docs
where Essn='012345678'

EXEC sp_OACreate 'ADODB.Stream', @init OUTPUT;
EXEC sp_OASetProperty @init, 'Type', 1;
EXEC sp_OAMethod @init, 'Open';
EXEC sp_OAMethod @init, 'Write', NULL, @BlobData; 
EXEC sp_OAMethod @init, 'SaveToFile', NULL, 'D:\Temp\BlobOutput.jpg', 2;
EXEC sp_OAMethod @init, 'Close'; 
EXEC sp_OADestroy @init;

