Create table Customer (CustId int not null,
                       CustName varchar(50) not null,
                       Address  varchar(50) not null,
                       City  varchar(50) not null,
                       State  varchar(50) not null,
                       PostalCode  varchar(50) not null,
                       primary key (custid))
go

sp_help customer

set nocount on

select @@TRANCOUNT

begin transaction T1

declare @i int

set @i = 1
while @i <= 1000000
begin
   insert into Customer (CustId, CustName, Address, City, State, PostalCode)
   select @i, convert(varchar, rand()*1000000) + 'ABC', '1234 1 Cross JP Nagar 3rd Phase', 'Bangalore', 'Karnataka', '560 078'
   set @i = @i + 1
end
go


commit transaction T1

set nocount off

select * from Customer where CustName = '829869ABC' 

select * from Customer where CustName like '95%ABC' 




create index CustomerName_Idx on customer(CustName)
go

sp_helpindex Customer
go

dbcc checktable (Customer)
go

dbcc showcontig(Customer)
go

delete from Customer where CustId between 7001 and 8000
go
delete from Customer where CustId between 14001 and 15000
go
delete from Customer where CustId between 21001 and 22000
go
delete from Customer where CustId between 36001 and 37000
go
delete from Customer where CustId between 41001 and 42000
go
delete from Customer where CustId between 461001 and 462000
go
delete from Customer where CustId between 372001 and 373000
go
delete from Customer where CustId between 283001 and 284000
go
delete from Customer where CustId between 191001 and 192000
go

dbcc indexdefrag (0, Customer,PK__Customer__049E3AA966516DB2)
go

dbcc indexdefrag (0, Customer,CustomerName_Idx)
go

dbcc dbreindex (Customer)
go

update statistics Customer
go

sp_updatestats
go

select 'dbcc indexdefrag(0, ' + so.name + ', ' + si.name + ')'
from sysobjects so,
     sysindexes si
where so.type = 'u' and
      si.id = so.id and 
      si.indid > 0
go

create table CustomerOrder (OrderNumber int not null,
                      OrderDate datetime not null,
                      CustId int not null foreign key references CUSTOMER (CustId) on delete cascade,
                      OrdAmt int not null default 0,
                      primary key (OrderNumber))
go

select * from CustomerOrder

set nocount on

select @@TRANCOUNT

begin transaction T1

declare @i int

set @i = 1
while @i <= 1000000
begin
   insert into CustomerOrder (OrderNumber, OrderDate, CustId, OrdAmt)
   select @i, GETDATE(), @i, rand()*1000
   set @i = @i + 1
end
go


commit transaction T1

set nocount off

select * from CustomerOrder where CustID = '500000' 

select C.CustName, C.City, CO.OrdAmt
from CustomerOrder CO,
     Customer C
where CO.CustID = C.CustId and 
      C.CustId = 500000

create index CustomerOrderCustIDx on CustomerOrder(CustId)

select C.CustName, C.City, CO.OrdAmt
from CustomerOrder CO,
     Customer C
where CO.CustID = C.CustId and 
      C.CustName like '95%ABC'

drop index Customer.CustomerName_Idx
go

create index CustomerName_Idx on customer(CustName, City)
go

create index CustomerOrder_Idx on customerOrder(CustId)
go

drop index customerOrder.CustomerOrder_Idx
go

create index CustomerOrder_Idx on customerOrder(CustId, OrdAmt)
go

select C.CustName, C.City, sum(CO.OrdAmt)
from CustomerOrder CO,
     Customer C
where CO.CustID = C.CustId and 
      C.CustName like '95%ABC'
group by C.CustName, C.City


select C.CustName, C.City, sum(CO.OrdAmt)
from CustomerOrder CO,
     Customer C
where CO.CustID = C.CustId and 
      C.CustName like '95%ABC'
group by C.CustName, C.City
having sum(CO.OrdAmt) >= 2000